--
-- PostgreSQL database dump
--

-- Dumped from database version 10.6 (Debian 10.6-1.pgdg90+1)
-- Dumped by pg_dump version 10.6 (Debian 10.6-1.pgdg90+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: activities_activities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.activities_activities (
    id integer NOT NULL,
    project_name character varying(300) NOT NULL,
    portfolio character varying(50) NOT NULL,
    cluster character varying(50) NOT NULL,
    specific_activity character varying(300) NOT NULL,
    start_date character varying(50) NOT NULL,
    end_date character varying(50),
    donor_1 character varying(50),
    donor_2 character varying(50),
    donor_3 character varying(50),
    activity_value character varying(50),
    beneficiaries character varying(50),
    category_id integer NOT NULL,
    location_id integer NOT NULL,
    sdg_id integer NOT NULL,
    topic_id integer NOT NULL,
    sublocation_id integer
);


ALTER TABLE public.activities_activities OWNER TO postgres;

--
-- Name: activities_activities_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.activities_activities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.activities_activities_id_seq OWNER TO postgres;

--
-- Name: activities_activities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.activities_activities_id_seq OWNED BY public.activities_activities.id;


--
-- Name: activities_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.activities_category (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.activities_category OWNER TO postgres;

--
-- Name: activities_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.activities_category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.activities_category_id_seq OWNER TO postgres;

--
-- Name: activities_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.activities_category_id_seq OWNED BY public.activities_category.id;


--
-- Name: activities_location; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.activities_location (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    latitude numeric(30,15) NOT NULL,
    longitude numeric(30,15) NOT NULL
);


ALTER TABLE public.activities_location OWNER TO postgres;

--
-- Name: activities_location_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.activities_location_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.activities_location_id_seq OWNER TO postgres;

--
-- Name: activities_location_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.activities_location_id_seq OWNED BY public.activities_location.id;


--
-- Name: activities_sdg; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.activities_sdg (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.activities_sdg OWNER TO postgres;

--
-- Name: activities_sdg_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.activities_sdg_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.activities_sdg_id_seq OWNER TO postgres;

--
-- Name: activities_sdg_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.activities_sdg_id_seq OWNED BY public.activities_sdg.id;


--
-- Name: activities_topic; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.activities_topic (
    id integer NOT NULL,
    name character varying(100) NOT NULL
);


ALTER TABLE public.activities_topic OWNER TO postgres;

--
-- Name: activities_topic_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.activities_topic_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.activities_topic_id_seq OWNER TO postgres;

--
-- Name: activities_topic_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.activities_topic_id_seq OWNED BY public.activities_topic.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO postgres;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_user_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_user_groups_id_seq OWNED BY public.auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO postgres;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_user_id_seq OWNED BY public.auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_user_user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_user_user_permissions_id_seq OWNED BY public.auth_user_user_permissions.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO postgres;

--
-- Name: activities_activities id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_activities ALTER COLUMN id SET DEFAULT nextval('public.activities_activities_id_seq'::regclass);


--
-- Name: activities_category id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_category ALTER COLUMN id SET DEFAULT nextval('public.activities_category_id_seq'::regclass);


--
-- Name: activities_location id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_location ALTER COLUMN id SET DEFAULT nextval('public.activities_location_id_seq'::regclass);


--
-- Name: activities_sdg id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_sdg ALTER COLUMN id SET DEFAULT nextval('public.activities_sdg_id_seq'::regclass);


--
-- Name: activities_topic id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_topic ALTER COLUMN id SET DEFAULT nextval('public.activities_topic_id_seq'::regclass);


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: auth_user id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user ALTER COLUMN id SET DEFAULT nextval('public.auth_user_id_seq'::regclass);


--
-- Name: auth_user_groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups ALTER COLUMN id SET DEFAULT nextval('public.auth_user_groups_id_seq'::regclass);


--
-- Name: auth_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_user_user_permissions_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Data for Name: activities_activities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.activities_activities (id, project_name, portfolio, cluster, specific_activity, start_date, end_date, donor_1, donor_2, donor_3, activity_value, beneficiaries, category_id, location_id, sdg_id, topic_id, sublocation_id) FROM stdin;
1	BIOMASS	Energy	Resilient Development	Biomass/biogas combined heat and power (CHP) plant (200 kW installed capacity)	13.11.2015.	02.03.2018.	GEFTrustee			222400.4		3	1	7	7	2
2	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity developemnt of the police to respond to VaW			SIDA					7	1	5	6	1
3	Enhancement of Municipal Audit for Accountability and Efficiency in Public Finance Management	Accountable Governance 	Public Finance Management 	Enhancing cooperation of LGs, CSOs and media for more accoutable PFM	2015-11-01 00:00:00	Ongoing	SDC			6000.0		7	1	16	4	1
4	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	19.10.2017	Ongoing	GEFTrustee					7	3	7	7	3
5	BIOMASS	Energy	Resilient Development	Biomass/biogas combined heat and power (CHP) plant (3.57 MW installed capacity)	13.11.2015.	01.07.2016.	GEFTrustee			275519.92		3	4	7	7	5
6	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	19.10.2017	Ongoing	GEFTrustee					7	4	7	7	4
7	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	19.10.2017	Ongoing	GEFTrustee					7	6	7	7	6
8	Integrated Response VaW	Social Inclusion	Social Inclusion	Support to the multisectoral teams to implement Law on Preventing Domestic Violence	24.10.2017	13.02.2018	SIDA					7	6	5	6	6
9	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity developemnt of the police to respond to VaW			SIDA					7	6	5	6	6
10	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity developemnt of the police to respond to VaW			SIDA					7	7	5	6	7
11	BIOMASS	Energy	Resilient Development	Biomass/biogas combined heat and power (CHP) plants (3 plants, 1.95 MW total installed capacity)	13.11.2015.	01.12.2016; 13.12.2017.	GEFTrustee			826559.76		3	8	7	7	8
12	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	19.10.2017	Ongoing	GEFTrustee					7	9	7	7	9
13	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	To train and employ young Roma women and men in institutions and organizations at the local level	01.02.2018	ongoing	UNHCR			3600.0	1	4	9	10	5	9
14	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	19.10.2017	Ongoing	GEFTrustee					7	10	7	7	11
15	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of the Torrential Barrier - 50 m	14.7.2014	31.12.2015.	UNDP			29112.24	27904	3	10	11	10	11
16	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of the Torrential Barrier - 170 m	14.7.2014	31.12.2015.	UNDP			66767.56	27904	3	10	11	10	11
17	Integrated Response VaW	Social Inclusion	Social Inclusion	Support to the multisectoral teams to implement Law on Preventing Domestic Violence	14.12.2017	01.02.2017	SIDA					7	12	5	6	12
18	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity developemnt of the police to respond to VaW			SIDA					7	12	5	6	12
19	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	19.10.2017	Ongoing	GEFTrustee					7	13	7	7	13
20	MEAs	ENV & NRM		Local Adaptation Activities and Measures	2018-09-01 00:00:00	2018-12-31 00:00:00	GEFTrustee			5000.0		7	13	13	8	13
21	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	To train and employ young Roma women and men in institutions and organizations at the local level	01.02.2018	ongoing	UNHCR			3600.0	1	4	14	10	5	14
22	Open Communities-Successful Communities	Local Development 	Resilient Development	Procurement of Waste Collection Truck - PUC "Komunalac"	4.12.2017	26.7.2018	EU			74626.0	12135	3	14	11	10	14
23	Strengthening local resilience in Serbia: Mitigating the impact of the migration crisis	Local Resilience Development	Resilient Development	Procurement of the Septic truck for the PUC Belgrade	17.3.2016.	17.8.2017.	SIDA			73760.0	1683960	3	15	11	10	15
24	strenghtening local resilience	Local Resilience Development	Resilient Development	Procurement of one vehicle for the Center for Social Work	1.1.2016.	31.12.2016.	UNDP			12300.0	1683960	6	15	11	10	15
25	strenghtening local resilience	Local Resilience Development	Resilient Development	Procurement of pick-up vehicle for the Institute for Biocides and Medical Ecology in Belgrade	1.1.2016	31.12.2016	UNDP			11734.0	980	3	15	11	10	15
26	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for provision of SOS help-line service	1.5.2017	20.12.2017	SIDA			2500.0	1	7	15	5	6	15
27	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for marking 16 days of activism against VaW campaign	1.10.2017	20.12.2017	SIDA			2000.0	1	7	15	5	6	15
28	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for provision of SOS help-line service	1.11.2018	Ongoing	SIDA			5000.0	1	7	15	5	6	15
29	Integrated Response VaW	Social Inclusion	Social Inclusion	Support to group Journalists against Violence	1.10.2017	Ongoing	SIDA			10000.0	27	7	15	5	6	15
30	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	19.10.2017	Ongoing	GEFTrustee					7	15	7	7	16
31	Open Communities-Successful Communities	Local Development 	Resilient Development	Development of the Design for Building Premit for Reconstruction of the City of Belgrade Institute of Emergency Medical Assistance	22.7.2018	22.12.2018	EU			94200.0	1000000	1	15	11	10	15
33	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	To train and employ young Roma women and men in institutions and organizations at the local level	01.02.2018	ongoing	UNHCR			3600.0	1	4	18	10	5	18
34	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	To train and employ young Roma women and men in institutions and organizations at the local level	01.02.2018	ongoing	UNHCR			18000.0	5	4	15	10	5	15
35	Autonomy, Voice and Participation of PWDs in Serbia	Social Inclusion	Social Inclusion	To train OPDs and CSOs on self-advocacy and employment of PWDs	01.06.2018.	ongoing	UN			2000.0	20	7	15	10	5	15
36	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity development of professionals to implement Law on Preventing Domestic Violence 	1.11.2018	Ongoing	SIDA					9	19	5	6	19
37	Integrated Response VaW	Social Inclusion	Social Inclusion	Support to the multisectoral teams to implement Law on Preventing Domestic Violence	17.10.2018	ongoing	SIDA					9	19	5	6	19
38	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity developemnt of the police to respond to VaW	7.11.2018	ongoing	SIDA					9	19	5	6	19
39	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity development of professionals to implement Law on Preventing Domestic Violence 	1.11.2018	Ongoing	SIDA					9	20	5	6	20
40	Integrated Response VaW	Social Inclusion	Social Inclusion	Support to the multisectoral teams to implement Law on Preventing Domestic Violence	17.10.2018	ongoing	SIDA					9	20	5	6	20
41	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity developemnt of the police to respond to VaW	7.11.2018	ongoing	SIDA					9	20	5	6	20
42	Strengthening local resilience in Serbia: Mitigating the impact of the migration crisis	Local Resilience Development	Resilient Development	Preparation of the design for the construction permit and the design for the construction of an urban waste water treatement facility 	17.3.2016.	17.8.2017.	JPN			65000.0	2624	3	21	11	10	21
43	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Development of the technical design for Upgrading Emergency Rooms 	12.3.2017.	25.4.2017.	USAID			5910.0	2624	1	21	3	10	21
44	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Construction works on Upgrading Emergency Rooms 	1.6.2017.	20.10.2017.	USAID			109980.0	2624	3	21	3	10	21
45	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Procurement of equipment and furniture for Emergency Room	20.10.2017.	21.11.2017.	USAID			10000.0	2624	3	21	3	10	21
46	Open Communities-Successful Communities	Local Development 	Resilient Development	Procurement of Terrain Vehicle for Bosilegrad Municipality Emergency Responce Team 	20.11.2017	30.11.2017	EU			15642.78	8129	3	21	11	10	21
47	Open Communities-Successful Communities	Local Development 	Resilient Development	Procurement of waste containers - PUC "Usluga"		30.11.2017	EU			3888.8	8129	3	21	11	10	21
48	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for marking 16 days of activism against VaW campaign	1.10.2017	20.12.2017	SIDA			1998.0	1	7	22	5	6	22
49	Open Communities-Successful Communities	Local Development 	Resilient Development	Procurement of Waste Collection Truck - PUC "Komunalac"	15.01.2018	26.7.2018	EU			74626.0	38000	3	23	11	10	23
50	Open Communities-Successful Communities	Local Development 	Resilient Development	Procurement of waste containers - PUC "Komunalac"		8.10.2018	EU			2376.56	38200	3	23	11	10	23
51	Open Communities-Successful Communities	Local Development 	Resilient Development	Furnishing of multiethnic kindergartner "Nasa radost"	1.11.2018	10.12.2018	EU			7075.99	266	3	23	11	10	23
52	Open Communities-Successful Communities	Local Development 	Resilient Development	Hydrogeologic Researches and Drilling of the Exploratory Well	25.10.2017	1.5.2018	EU			24200.0	10000	2	23	11	10	23
53	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	To train and employ young Roma women and men in institutions and organizations at the local level	01.02.2018	ongoing	UNHCR			3600.0	1	4	23	10	5	23
54	Integrated Response VaW	Social Inclusion	Social Inclusion	Piloting of the Law on Preventing Domsetic Violence	01.04.2017	01.06.2017	SIDA					9	24	5	6	24
55	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity development of professionals to implement Law on Preventing Domestic Violence 	1.11.2018	Ongoing	SIDA					9	25	5	6	25
56	Integrated Response VaW	Social Inclusion	Social Inclusion	Support to the multisectoral teams to implement Law on Preventing Domestic Violence	17.10.2018	ongoing	SIDA					9	25	5	6	25
57	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity developemnt of the police to respond to VaW	7.11.2018	ongoing	SIDA					9	25	5	6	25
58	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	19.10.2017	ongoing	GEFTrustee					7	26	7	7	26
59	CSUD	Climate change	Resilient Development	Innovation award for innovative idea within Open Data Challenge, Improving management and opening of local climate change related data 	04.06.2018	Ongoing	GEFTrustee	UNDP	SRB MoE	8000.0		10	26	13	8	26
60	Strengthening local resilience in Serbia: Mitigating the impact of the migration crisis	Local Resilience Development	Resilient Development	Procurement of the garbage truck 	17.3.2016.	17.8.2017.	JPN			93140.0	6278	6	27	11	10	27
61	Open Communities-Successful Communities	Local Development 	Resilient Development	Renovation of Social Welfare Centre	17.10.2017	31.1.2018	EU			19759.47	1493	3	27	11	10	27
62	ReLOaD	Accountable Governance 	Public Finance Management 	Support to LGs for more transparent financing of CSOs' projects that address the needs of local communities	1.02.2017	ongoing	EU	UNDP		900000.0	3000	7	28	16	4	27
63	Integrated Response VaW	Social Inclusion	Social Inclusion	Support to the multisectoral teams to implement Law on Preventing Domestic Violence	08.12.2018	14.03.2019	SIDA					7	29	5	6	29
64	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity developemnt of the police to respond to VaW			SIDA					7	29	5	6	29
65	Integrated Response VaW	Social Inclusion	Social Inclusion	Support to the multisectoral teams to implement Law on Preventing Domestic Violence	08.12.2019	14.03.2020	SIDA					7	30	5	6	30
66	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity developemnt of the police to respond to VaW			SIDA					7	30	5	6	30
67	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	19.10.2017.	ongoing	GEFTrustee					7	31	7	7	31
68	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	19.10.2017.	ongoing	GEFTrustee					7	32	7	7	32
69	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	19.10.2017.	ongoing	GEFTrustee					7	33	7	7	33
70	Strengthening local resilience in Serbia: Mitigating the impact of the migration crisis	Local Resilience Development	Resilient Development	Construction works on adaptation of the Red Cross building	17.3.2016.	17.8.2017.	JPN			69841.0	1930	3	34	11	10	34
71	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Construction works on Fairgrounds 	18.10.2016	20.11.2016.	USAID			54536.0	9871	3	34	11	10	34
72	Open Communities-Successful Communities	Local Development 	Resilient Development	Reconstruction of the Fire Brigade Premises	15.8.2018	20.12.2018	EU			117156.0	25000	3	34	11	10	34
73	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Renovation works in Kindergarten 	5.5.2017.	19.7.2017.	USAID			33796.0	110	3	35	4	10	36
74	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Procurement of Furniture for Kindergarden	20.7.2017.	31.7.2017.	USAID			5726.0	110	3	35	4	10	36
75	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for marking 16 days of activism against VaW campaign	1.10.2017	20.12.2017	SIDA			2000.0	1	7	35	5	6	35
76	Open Communities-Successful Communities	Local Development 	Resilient Development	Procurement of Septic Cleaning Truck 	4.12.2017	8.5.2018	EU			70976.0	59453	3	35	6	10	35
77	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	19.10.2017	ongoing	GEFTrustee					7	37	7	7	37
78	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Rain water collector in Brza Palanka sewerage (110m)	1.3.2015	30.3.2016.	JPN			23231.69	720	3	37	6	10	37
79	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Preparation of project designs for torrential dam construction and rived bad cleaning/regulation	1.3.2015	30.3.2016.	JPN			8000.0	465	1	37	11	10	37
80	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Preparation of project designs for torrential dam construction and rived bad cleaning/regulation	1.3.2015	30.3.2016.	JPN			11000.0	212	1	37	11	10	37
81	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity development of professionals to implement Law on Preventing Domestic Violence 	1.11.2018	Ongoing	SIDA					9	37	5	6	37
82	Integrated Response VaW	Social Inclusion	Social Inclusion	Support to the multisectoral teams to implement Law on Preventing Domestic Violence	17.10.2018	ongoing	SIDA					9	37	5	6	37
83	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity developemnt of the police to respond to VaW	7.11.2018	ongoing	SIDA					9	37	5	6	37
84	Integrated Response VaW	Social Inclusion	Social Inclusion	Support to the multisectoral teams to implement Law on Preventing Domestic Violence	14.12.2017	01.02.2017	SIDA					7	38	5	6	38
85	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity developemnt of the police to respond to VaW			SIDA					7	38	5	6	38
86	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	19.10.2017	ongoing	GEFTrustee					7	39	7	7	39
87	EMIS	Energy	Resilient Development	Improvement of energy efficiency of the “Knjazevacka gimnazija” high school building	20.04.2017	08.12.2017	GEFTrustee	SRB MoME	Knjaževac	48663.0		3	39	7	7	39
88	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Preparation of project designs for torrential dam construction and rived bad cleaning/regulation	1.3.2015	30.3.2016.	JPN			8000.0	210	1	40	11	10	41
89	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Preparation of project designs for torrential dam construction and rived bad cleaning/regulation	1.3.2015	30.3.2016.	JPN			8000.0	204	1	40	11	10	40
90	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Rehabilitation of landslide, wells in Đukovine 	1.3.2015	30.3.2016.	JPN			15100.0	343	1	40	11	10	40
91	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of the Torrential Barrier - 85 m	14.7.2014	31.12.2015.	UNDP			46437.38	12743	3	42	11	10	42
92	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of the Torrential Barrier - 179 m	14.7.2014	31.12.2015.	UNDP			36964.02	12743	3	42	11	10	42
93	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of the Torrential Barrier - 80 m	14.7.2014	31.12.2015.	UNDP			56764.79	12743	3	42	11	10	42
94	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	To train and employ young Roma women and men in institutions and organizations at the local level	01.02.2018	ongoing	UNHCR			3600.0	1	4	43	10	5	43
95	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	12.3.2018.	ongoing	GEFTrustee					7	44	7	7	44
96	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Preparation of project design for partial regulation of Lepenica river 	1.3.2015	30.3.2016.	JPN			16800.0	92000	1	44	11	10	44
97	Autonomy, Voice and Participation of PWDs in Serbia	Social Inclusion	Social Inclusion	To train OPDs and CSOs on self-advocacy and employment of PWDs	01.06.2018.	ongoing	UN			2000.0	20	7	44	10	5	44
98	Integrated Response VaW	Social Inclusion	Social Inclusion	Support to the multisectoral teams to implement Law on Preventing Domestic Violence	14.12.2017	01.02.2017	SIDA					7	44	5	6	44
99	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant to work with perpatrators programs and support to victims	1.11.2018	Ongoing	SIDA			10000.0	2	10	44	5	6	44
100	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	To train and employ young Roma women and men in institutions and organizations at the local level	01.02.2018	ongoing	UNHCR			3600.0	1	4	44	10	5	44
101	ReLOaD	Accountable Governance	Public Finance Management	Support to LGs for more transparent financing of CSOs' projects that address the needs of local communities	1.02.2017	ongoing	EU	UNDP		900000.0	3000	7	44	16	4	44
102	CSUD	Climate Change	Resilient Development	Innovation award for innovative idea within Open Data Challenge, Improving management and opening of local climate change related data 	4.6.2018	Ongoing	GEFTrustee	UNDP	SRB MoE	9000.0		10	44	13	8	44
103	Enhancement of Municipal Audit for Accountability and Efficiency in Public Finance Management	Accountable Governance 	Public Finance Managment	Enhancing cooperation of LGs, CSOs and media for more accoutable PFM	2015-11-01 00:00:00	Ongoing	SDC			5000.0		7	44	16	4	44
104	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for provision of SOS help-line service	1.5.2017	20.12.2017	SIDA			4500.0	1	7	45	5	6	45
105	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for provision of SOS help-line service	1.11.2018	Ongoing	SIDA			5000.0	1	7	45	5	6	45
106	CSUD	Climate Change	Resilient Development	Innovation award for innovative idea within Open Data Challenge, Improving management and opening of local climate change related data 	04.06.2018.	Ongoing	GEFTrustee	UNDP	SRB MoE	4000.0		10	45	13	8	45
107	CSUD	Climate Change	Resilient Development	Innovation award within Innovation Challenge. Improving detection of forest fires and establishing an early detection system 	27.4.2018.	Ongoing	GEFTrustee	UNDP	SRB MoE	5000.0		10	45	13	8	45
108	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Construction of the new bridge 	1.3.2015	30.3.2016.	JPN			102910.32	3000	3	46	11	10	46
109	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Preparation of the project design for rehabilitation of the tailing landfill next to mine Stolice, Krupanj municipality	1.3.2015	30.3.2016.	JPN			204300.0	15000	1	46	11	10	46
110	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Rehabilitation of landslide near elementary school in Likodra	1.3.2015	30.3.2016.	JPN			94849.47	842	3	46	11	10	47
111	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of the Torrential Barrier - 150 m	14.7.2014	31.12.2015.	UNDP			29486.71	18427	3	46	11	10	48
112	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of the Torrential Barrier - 200 m	14.7.2014	31.12.2015.	UNDP			42946.82	18427	3	46	11	10	46
113	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of the Torrential Barrier - 150 m	14.7.2014	31.12.2015.	UNDP			28707.45	18427	3	46	11	10	46
114	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of the Torrential Barrier - 100 m	14.7.2014	31.12.2015.	UNDP			52791.66	18427	3	46	11	10	46
115	CSUD	Climate Change	Resilient Development	Innovation award for innovative idea within Open Data Challenge, Improving management and opening of local climate change related data	04.06.2018.	Ongoing	GEFTrustee	UNDP	SRB MoE	7000.0		10	46	13	8	46
116	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	19.10.2017	ongoing	GEFTrustee					7	49	7	7	49
117	EMIS	Energy	Resilient Development	Improvement of energy efficiency of the multi-purpose public building in Trmcare and conversion of the heating system from solid fuel to gas	20.04.2017	20.10.2018.	GEFTrustee	SRB MoME	Kruševac	16114.52		3	49	7	7	49
118	Integrated Response VaW	Social Inclusion	Social Inclusion	Piloting of the Law on Preventing Domsetic Violence	01.04.2017	01.06.2017	SIDA					9	49	5	6	49
119	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for provision of SOS help-line service	1.5.2017	20.12.2017	SIDA			5000.0	1	7	49	5	6	49
120	CSUD	Climate Change	Resilient Development	Innovation award for innovative idea within Open Data Challenge, Improving management and opening of local climate change related data 	04.06.2018	Ongoing	GEFTrustee	UNDP	SRB MoE	10000.0		10	49	13	8	49
121	CSUD	Climate Change	Resilient Development	Innovation award within Innovation Challenge. Introducing new business model for municipal energy management	27.04.2018.	ongoing	GEFTrustee	UNDP	SRB MoE	4000.0		10	49	13	8	49
122	Enhancement of Municipal Audit for Accountability and Efficiency in Public Finance Management	Accountable Governance 	Public Finance Managment	Support to LGs for more transparent financing of CSOs' projects that address the needs of local communities	2015-11-01 00:00:00	ongoing		SDC		5000.0		7	49	16	4	49
123	Integrated Response VaW	Social Inclusion	Social Inclusion	Support to the multisectoral teams to implement Law on Preventing Domestic Violence	24.10.2017	13.02.2018	SIDA					7	50	5	6	50
124	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity developemnt of the police to respond to VaW			SIDA					7	50	5	6	50
125	ReLOaD	Accountable Governance 	Public Finance Managment	Support to LGs for more transparent financing of CSOs projects that address the needs of local communities	1.02.2017	ongoing	EU	UNDP		900000.0	3000	7	51	16	4	51
126	Strengthening local resilience in Serbia: Mitigating the impact of the migration crisis	Local Resilience Development	Resilient Development	Procurement and installation of children playground mobilier 	17.3.2016.	17.8.2017.	JPN			4161.0	423	3	52	3	10	52
127	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Construction of multifunctional sports field	31.7.2017.	1.9.2017.	USAID			49902.0	1140	3	52	3	10	52
128	Open Communities - Successful Communities 	Local Resilience Development	Resilient Development	Renovation and furbishing of  an Infirmary in Bogovadja village			EU			60000.0	217	3	52	3	10	53
129	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	To train and employ young Roma women and men in institutions and organizations at the local level	01.02.2018	ongoing	UNHCR			3600.0	1	4	52	10	5	52
130	EMIS	Energy	Resilient Development	Reconstruction of the heating system through installation of a pellet fired boiler with thermo-technical installations and improvement of thermal insulation including replacement of outer doors and windows of the Town Hall building	20.04.2017	23.02.2018	GEFTrustee	SRB MoME	Lapovo	46895.0		3	54	7	7	54
131	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity developemnt of the police to respond to VaW			SIDA					7	54	5	6	54
132	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Reconstruction of bridge over Lukavica river in Šopići community	1.3.2015	30.3.2016.	JPN			72769.96	2619	3	55	6	10	55
133	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Preparation of the Study on Flood Risk Management in the Kolubara River Basin	1.3.2015	30.3.2016.	JPN			464250.0	1300000	1	55	11	10	55
134	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	19.10.2017	ongoing	GEFTrustee					7	56	7	7	56
135	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity development of professionals to implement Law on Preventing Domestic Violence 	1.11.2018	Ongoing	SIDA					9	56	5	6	56
136	Integrated Response VaW	Social Inclusion	Social Inclusion	Support to the multisectoral teams to implement Law on Preventing Domestic Violence	17.10.2018	ongoing	SIDA					9	56	5	6	56
137	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity developemnt of the police to respond to VaW	7.11.2018	ongoing	SIDA					9	56	5	6	56
138	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	19.10.2017	ongoing	GEFTrustee					7	57	7	7	57
139	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for marking 16 days of activism against VaW campaign	1.10.2017	20.12.2017	SIDA			1865.0	1	7	57	5	6	57
140	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity development of professionals to implement Law on Preventing Domestic Violence 	1.11.2018	Ongoing	SIDA					9	57	5	6	57
141	Integrated Response VaW	Social Inclusion	Social Inclusion	Support to the multisectoral teams to implement Law on Preventing Domestic Violence	17.10.2018	ongoing	SIDA					9	57	5	6	57
142	Enhancement of Municipal Audit for Accountability and Efficiency in Public Finance Management	Accountable Governance	Public Finance Management	Support to LGs for more transparent financing of CSOs projects that address the needs of local communities	2015-11-01 00:00:00	ongoing	SDC			6000.0		7	57	16	4	57
143	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity developemnt of the police to respond to VaW	7.11.2018	ongoing	SIDA					9	57	5	6	57
144	EMIS	Energy	Resilient Development	Improvement of energy efficiency of the Town Hall	20.04.2017	18.07.2018	GEFTrustee	SRB MoME	Ljubovija	40959.48		3	58	7	7	58
145	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Construction of the torrential dam on Ljuboviđa river	1.3.2015	30.3.2016.	JPN			160179.56	3000	3	58	9	10	58
146	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Rehabilitation of landslide in Brcic	1.3.2015	30.3.2016.	JPN			14600.0	160	1	58	11	10	58
147	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of the Torrential Barrier - 410 m	14.7.2014	31.12.2015.	UNDP			37818.08	15285	3	58	11	10	58
148	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Rehabilitation of landslide in Banja Koviljača	1.3.2015	30.3.2016.	JPN			104997.0	680	3	59	11	10	60
149	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of the Torrential Barrier - 150 m	14.7.2014	31.12.2015.	UNDP			44831.51	83915	3	59	11	10	61
150	Open Communities-Successful Communities	Local Development 	Resilient Development	Renovation of the School Plateau of "Vera Blagojevic" Elementary School	10.7.2018	3.9.2018	EU			61009.0	478	3	59	11	10	60
151	Enhancement of Municipal Audit for Accountability and Efficiency in Public Finance Management	Accountable Governance	Public Finance Management	Support to LGs for more transparent financing of CSOs projects that address the needs of local communities	2015-11-01 00:00:00	ongoing	SDC			6000.0		7	59	16	4	59
152	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	19.10.2017	ongoing	GEFTrustee					7	62	7	7	62
153	EMIS	Energy	Resilient Development	Design for adaptation and reconstruction of the Municipal Administration building	20.04.2017	28.03.2018	GEFTrustee	SRB MoME	Lučani	50000.0		1	62	7	7	62
154	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Rehabilitation of the landslide in Kapetanska street	1.3.2015	30.3.2016.	JPN			17300.0	5500	1	63	11	10	63
155	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity development of professionals to implement Law on Preventing Domestic Violence 	1.11.2018	Ongoing	SIDA					9	63	5	6	63
156	Integrated Response VaW	Social Inclusion	Social Inclusion	Support to the multisectoral teams to implement Law on Preventing Domestic Violence	17.10.2018	ongoing	SIDA					9	63	5	6	63
157	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity developemnt of the police to respond to VaW	7.11.2018	ongoing	SIDA					9	63	5	6	63
158	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of the Torrential Barrier - 150 m	14.7.2014	31.12.2015.	UNDP			83749.8	13261	3	64	11	10	64
159	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of the Torrential Barrier - 150 m	14.7.2014	31.12.2015.	UNDP			70259.98	13261	3	64	11	10	64
160	EMIS	Energy	Resilient Development	First phase of the reconstruction and upgrade of the Town Hall (replacement of the heating system)\r\nMedvedja\r\n	20.04.2017	03.04.2018	GEFTrustee	SRB MoME	Medvedja	28640.94		3	65	7	7	65
161	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity development of professionals to implement Law on Preventing Domestic Violence 	1.11.2018	Ongoing	SIDA					9	65	5	6	65
162	Integrated Response VaW	Social Inclusion	Social Inclusion	Support to the multisectoral teams to implement Law on Preventing Domestic Violence	17.10.2018	ongoing	SIDA					9	65	5	6	65
163	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity developemnt of the police to respond to VaW	7.11.2018	ongoing	SIDA					9	65	5	6	65
164	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Construction of the torrential dam and cleaning of the river (350m) through Mala Kamenica village	1.3.2015	30.3.2016.	JPN			87507.4	604	3	66	9	10	66
165	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity development of professionals to implement Law on Preventing Domestic Violence 	1.11.2018	Ongoing	SIDA					9	66	5	6	66
166	Integrated Response VaW	Social Inclusion	Social Inclusion	Support to the multisectoral teams to implement Law on Preventing Domestic Violence	17.10.2018	ongoing	SIDA					9	66	5	6	66
167	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity developemnt of the police to respond to VaW	7.11.2018	ongoing	SIDA					9	66	5	6	66
168	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	19.10.2017	ongoing	GEFTrustee					7	67	7	7	67
169	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	19.10.2017	ongoing	GEFTrustee					7	67	7	7	67
170	Reintegration of Roma returnees	Social Inclusion	Social Inclusion	Ensuring access to housing and employment for Roma returnees	01.01.2016	30.06.2018	UNDP			64100.0	142	10	67	1	5	67
171	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	To train and employ young Roma women and men in institutions and organizations at the local level	01.02.2018	ongoing	UNHCR			10800.0	3	4	67	10	5	67
172	Integrated Response VaW	Social Inclusion	Social Inclusion	Support to the multisectoral teams to implement Law on Preventing Domestic Violence	08.12.2017	14.03.2018	SIDA					7	67	5	6	67
173	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity developemnt of the police to respond to VaW			SIDA					7	67	5	6	67
174	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for provision of SOS help-line service	1.5.2017	20.12.2017	SIDA			2000.0	1	7	67	5	6	67
175	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for marking 16 days of activism against VaW campaign	1.10.2017	20.12.2017	SIDA			4000.0	2	7	67	5	6	67
176	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for provision of SOS help-line service	1.11.2018	Ongoing	SIDA			5000.0	1	7	67	5	6	67
177	Autonomy, Voice and Participation of PWDs in Serbia	Social Inclusion	Social Inclusion	To train OPDs and CSOs on self-advocacy and employment of PWDs	01.06.2018.	ongoing	UN			2000.0	20	7	67	10	5	67
178	Blockchain Based Remittances in the City of Nis											10	67	12	1	67
179	Enhancement of Municipal Audit for Accountability and Efficiency in Public Finance Management	Accountable Governance	Public Finance Managament	Support to LGs for more transparent financing of CSOs projects that address the needs of local communities	2015-11-01 00:00:00	ongoing	SDC			6000.0		7	67	16	4	67
180	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	To train and employ young Roma women and men in institutions and organizations at the local level	01.02.2018	ongoing	UNHCR			3600.0	1	4	68	10	5	68
181	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity development of professionals to implement Law on Preventing Domestic Violence 	1.11.2018	Ongoing	SIDA					9	69	5	6	69
182	Integrated Response VaW	Social Inclusion	Social Inclusion	Support to the multisectoral teams to implement Law on Preventing Domestic Violence	17.10.2018	ongoing	SIDA					9	69	5	6	69
183	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity developemnt of the police to respond to VaW	7.11.2018	ongoing	SIDA					9	69	5	6	69
184	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for provision of SOS help-line service	1.5.2017	20.12.2017	SIDA			4500.0	1	7	70	5	6	70
185	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for marking 16 days of activism against VaW campaign	1.10.2017	20.12.2017	SIDA			1000.0	1	7	70	5	6	70
186	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	To train and employ young Roma women and men in institutions and organizations at the local level	01.02.2018	ongoing	UNHCR			3600.0	1	4	71	10	5	71
187	Enhancement of Municipal Audit for Accountability and Efficiency in Public Finance Management	Accountable Governance	Public Finance Management	Support to LGs for more transparent financing of CSOs projects that address the needs of local communities	2015-11-01 00:00:00	Ongoing				5000.0		7	71	16	4	71
188	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	14.11.2018.	ongoing	GEFTrustee					7	72	7	7	72
189	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for provision of SOS help-line service	1.5.2017	20.12.2017	SIDA			4990.0	1	7	72	5	6	72
190	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for provision of SOS help-line service	1.11.2018	Ongoing	SIDA			5000.0	1	7	72	5	6	72
191	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant to work with perpatrators programs and support to victims	1.11.2018	Ongoing	SIDA			10000.0	2	10	72	5	6	72
192	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	To train and employ young Roma women and men in institutions and organizations at the local level	01.02.2018	ongoing	UNHCR			7200.0	2	4	72	10	5	72
193	Autonomy, Voice and Participation of PWDs in Serbia	Social Inclusion	Social Inclusion	To train OPDs and CSOs on self-advocacy and employment of PWDs	01.06.2018.	ongoing	UN			2000.0	20	7	72	10	5	72
194	Enhancement of Municipal Audit for Accountability and Efficiency in Public Finance Management	Accoutable Governance	Public Finance Management	Support to LGs for more transparent financing of CSOs projects that address the needs of local communities	2015-11-01 00:00:00	ongoing	SDC			5000.0		7	72	16	4	72
195	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Rehabilitation of landslide and road in Barič 	1.3.2015	30.3.2016.	JPN			16000.0	500	1	73	11	10	74
196	Open Communities-Successful Communities	Local Development 	Resilient Development	Procurement of the Water Transportation Cistern - PUC "Waterworks and Sewage"Obrenovac	4.12.2017	16.5.2018	EU			73700.0	71419	3	73	11	10	73
197	Open Communities-Successful Communities	Local Development 	Resilient Development	Modernization of the Water Treatement Plant "Zabrezje"	23.10.2017	28.2.2018	EU			80753.0	71419	3	73	11	10	75
198	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	To train and employ young Roma women and men in institutions and organizations at the local level	01.02.2018	ongoing	UNHCR			3600.0	1	4	76	10	5	76
199	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity developemnt of the police to respond to VaW			SIDA					7	76	5	6	76
200	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Main water supply line in Karadjordjeva street (700m)	1.3.2015.	30.3.2016.	JPN			65816.88	1901-11-20 00:00:00	3	77	6	10	77
201	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Main water supply line from KIK reservoir to Osečina (685m)	1.3.2015	30.3.2016.	JPN			60529.75	1200	3	77	6	10	77
202	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of the Torrential Barrier - 150 m	14.7.2014	31.12.2015.	UNDP			23683.9	12921	3	77	11	10	77
203	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of the Torrential Barrier - 150 m	14.7.2014	31.12.2015.	UNDP			9905.74	12921	3	77	11	10	77
204	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for marking 16 days of activism against VaW campaign	1.10.2017	20.12.2017	SIDA			2000.0	1	7	78	5	6	78
205	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	26.2.2018.	ongoing	GEFTrustee					7	78	7	7	78
206	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	To train and employ young Roma women and men in institutions and organizations at the local level	01.02.2018	ongoing	UNHCR			3600.0	1	4	78	10	5	78
371	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Budget portal			SDC					6	58	16	3	58
207	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Rain water collector in Zmić sewerage (770m)	1.3.2015	30.3.2016.	JPN			142562.9	10000	3	79	6	10	79
208	ReLOaD	Accountable Governance	Public Finance Management	Support to LGs for more transparent financing of CSOs' projects that address the needs of local communities	1.02.2017	Ongoing	EU	UNDP		900000.0	3000	7	79	16	4	79
209	EMIS	Energy	Resilient Development	Maintenance of the structure, construction of thermal insulation of the façade, and replacement of the coal-fired boiler with a pellet boiler at “Slobodan Bajic Paja” elementary school	20.04.2017	Ongoing	GEFTrustee	SRB MoME	Pećinci	29570.63		3	80	7	7	81
210	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	19.10.2017.	ongoing	GEFTrustee					7	82	7	7	82
211	Open Communities-Successful Communities	Local Development 	Resilient Development	Renovation and furnishing of the the "Dusan Radovic" Elementary School gymnasyium	20.11.2017	23.1.2018	EU			54800.0	658	3	83	11	10	83
212	Enhancement of Municipal Audit for Accountability and Efficiency in Public Finance Management	Accountable Governance 	Public Finance Management	\r\nSupport to LGs for more transparent financing of CSOs projects that address the needs of local communities\r\n	2015-11-01 00:00:00	ongoing	SDC			6000.0		7	84	16	4	84
213	Strengthening local resilience in Serbia: Mitigating the impact of the migration crisis	Local Resilience Development	Resilient Development	Regeneration and reconstruction of five wells at Žujince water spring	17.3.2016.	17.8.2017.	JPN			36750.0	7630	3	85	6	10	85
214	Strengthening local resilience in Serbia: Mitigating the impact of the migration crisis	Local Resilience Development	Resilient Development	Complete overhaul of the PUC “Moravica” in Presevo	17.3.2016.	17.8.2017.	JPN			28000.0	9780	3	85	9	10	85
215	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Procurement of 1,000 pieces of 120 l plastic waste bins 	1.12.2016.	19.12.2016.	USAID			16241.0	2320	3	85	11	10	86
216	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Design for construction of a new 1000m3 water reservoir 	1.8.2017.	28.9.2017.	USAID			23900.0	8400	1	85	6	10	85
217	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Construction of a new 1000m3 reservoir and renovation of existing 800m3 	9.10.2017.	24.11.2017.	USAID			308864.0	8400	3	85	6	10	85
218	Open Communities-Successful Communities	Local Development 	Resilient Development 	Construction and furnishing of the new Emergency Medicine Block 	25.4.2018	24.8.2018	EU			218500.0	34000	3	85	11	10	85
219	Open Communities-Successful Communities	Local Development 	Resilient Development 	Hydrogeologic Research of Toplik Watersource 	24.10.2017	26.12.2018	EU			25000.0	34000	2	85	11	10	87
220	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	19.10.2017.	ongoing	GEFTrustee					7	88	7	7	88
221	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity development of professionals to implement Law on Preventing Domestic Violence 	1.11.2018	Ongoing	SIDA					9	88	5	6	88
222	Integrated Response VaW	Social Inclusion	Social Inclusion	Support to the multisectoral teams to implement Law on Preventing Domestic Violence	17.10.2018	ongoing	SIDA					9	88	5	6	88
223	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity developemnt of the police to respond to VaW	7.11.2018	ongoing	SIDA					9	88	5	6	88
224	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity development of professionals to implement Law on Preventing Domestic Violence 	1.11.2018	Ongoing	SIDA					9	89	5	6	89
225	Integrated Response VaW	Social Inclusion	Social Inclusion	Support to the multisectoral teams to implement Law on Preventing Domestic Violence	17.10.2018	ongoing	SIDA					9	89	5	6	89
226	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity developemnt of the police to respond to VaW	7.11.2018	ongoing	SIDA					9	89	5	6	89
227	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	To train and employ young Roma women and men in institutions and organizations at the local level	01.02.2018	ongoing	UNHCR			3600.0	1	4	90	10	5	90
228	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity developemnt of the police to respond to VaW			SIDA					7	91	5	6	91
229	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	19.10.2017.	ongoing	GEFTrustee					7	92	7	7	92
230	EMIS	Energy	Resilient Development	Augmentation of energy efficiency of “Sutjeska” elementary school building – replacement of boilers and external joinery	20.04.2017	09.01.2018	GEFTrustee	SRB MoME	Raška	50000.0		3	92	7	7	93
231	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity developemnt of the police to respond to VaW			SIDA					7	94	5	6	94
232	Enhancement of Municipal Audit for Accountability and Efficiency in Public Finance Management	Accountable Governance 	Public Finance Management	\r\nSupport to LGs for more transparent financing of CSOs projects that address the needs of local communities\r\n	2015-11-01 00:00:00	ongoing	SDC			5000.0		7	95	16	4	95
233	EMIS	Energy	Resilient Development	Installation of the biomass fired boiler and reconstruction of the boiler room of the “Stojan Novakovic” elementary school	20.04.2017	28.06.2018	GEFTrustee	SRB MoME	Šabac	50000.0		3	96	7	7	96
234	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for marking 16 days of activism against VaW campaign	1.10.2017	20.12.2017	SIDA			1850.0	1	7	96	5	6	96
235	ReLOaD	Accountable Governance 	Public Finance Management	Support to LGs for more transparent financing of CSOs' projects that address the needs of local communities	1.02.2017	ongoing	EU	UNDP		900000.0	3000	7	96	16	4	96
236	CSUD	Climate Change	Resilient Development	Innovation award for innovative idea within Open Data Challenge, Improving management and opening of local climate change related data	04.06.2018.	Ongoing	GEFTrustee	UNDP	SRB MoE	5000.0		10	96	13	8	96
237	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	19.10.2017.	ongoing	GEFTrustee					7	97	7	7	97
238	Strengthening local resilience in Serbia: Mitigating the impact of the migration crisis	Local Resilience Development	Resilient Development	Reconstuction of sport fields in the elementary school in Adasevci 	17.3.2016.	17.8.2017.	JPN			49994.0	530	3	97	3	10	98
372	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Budget portal			SDC					6	14	16	3	14
239	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Procurement of Septic truck (cistern)	15.11.2016.	31.12.2016.	USAID			73760.0	3560	6	97	11	10	97
240	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Procurement of 10 pieces of 5m3 metal containers	1.12.2016.	20.12.2016.	USAID			7142.0	2050	3	97	11	10	97
241	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Renovation of Sports Fields and Open gym construction 	30.8.2017.	1.10.2017.	USAID			72063.0	10740	3	97	3	10	97
242	Open Communities-Successful Communities	Local Development 	Resilient Development	Renovation  and furbishing of "Sremski front" Elementary School branch	4.7.208	18.9.2018	EU			84500.0	987	3	97	11	10	99
243	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Regeneration of two wells and increasing yield in the city pipeline	1.3.2015	30.3.2016.	JPN				10000	3	97	11	10	97
244	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	19.10.2017.	ongoing	GEFTrustee					7	100	7	7	100
245	Open Communities-Successful Communities	Local Development 	Resilient Development	Procurement of the Water Transportation Cistern - PUC "Vrela"	4.12.2017	27.4.2018	EU			73700.0	26392	3	101	11	10	101
246	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	To train and employ young Roma women and men in institutions and organizations at the local level	01.02.2018	ongoing	UNHCR			3600.0	1	4	102	10	5	102
247	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Renovation of water source Buline vode	1.3.2015	30.3.2016.	JPN			39398.2	23600	3	103	11	10	103
248	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Construction of new water well (30m depth) in Buline vode water source	1.3.2015	30.3.2016.	JPN			31847.01	10000	3	103	11	10	103
249	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for provision of SOS help-line service	1.5.2017	20.12.2017	SIDA			2000.0	1	7	103	5	6	103
250	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Procurement of 5 pieces of 5m3 waste containers	15.3.2017.	20.4.2017.	USAID			3590.0	13200	3	104	11	10	104
251	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Renovation of Sports Fields and Open Gym Construction 	1.8.2017.	1.11.2017.	USAID			58191.0	25600	3	104	3	10	104
252	Integrated Response VaW	Social Inclusion	Social Inclusion	Support to the multisectoral teams to implement Law on Preventing Domestic Violence	24.10.2017	13.02.2018	SIDA					7	104	5	6	104
253	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity developemnt of the police to respond to VaW			SIDA					7	104	5	6	104
254				Upgrading of Sikara park - construction of children's playground	4.7.2018	30.10.2018	EU			24371.0	85903	3	104	3	10	104
255	Open Communities-Successful Communities	Local Development 	Resilient Development	Procurement of vehicle for Pre-school Facility "Vera Gucunja", City of Sombor	15.11.2018	14.12.2018	EU			16950.0	750	3	104	11	10	104
256	CSUD	Climate Change	Resilient Development	Innovation award for innovative idea within Open Data Challenge, Improving management and opening of local climate change related data 	4.6.2018	Ongoing	GEFTrustee	UNDP	SRB MoE	7000.0		10	105	13	8	105
257	Strengthening local resilience in Serbia: Mitigating the impact of the migration crisis	Local Resilience Development	Resilient Development	 Reconstruction of the Basketball sport court and construction of open space gym at Palić 	17.3.2016.	17.8.2017.	JPN			49900.0	7770	3	106	3	10	107
258	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Construction works on the Social Welfare Centre 	3.9.2016.	20.12.2016.	USAID			69485.0	32000	3	106	11	10	106
259	Open Communities-Successful Communities	Local Resilience Development	Resilient Development	Replacement of Roof Cover on Subotica Social Welfare Centre 	20.11.2017	12.1.2018	EU			116653.0	32000	3	106	11	10	106
260	Reintegration of Roma returnees	Social Inclusion	Social Inclusion	Ensuring access to education and personal documentation for Roma retturnees 	01.01.2016	30.06.2018	UNDP			20000.0	105	4	106	1	5	106
261	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	To train and employ young Roma women and men in institutions and organizations at the local level	01.02.2018	ongoing	UNHCR			3600.0	1	4	106	10	5	106
262	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	19.10.2017.	ongoing	GEFTrustee					7	108	7	7	108
263	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	19.10.2017.	ongoing	GEFTrustee					7	109	7	7	109
264	EMIS	Energy	Resilient Development	Conceptual design for maintenance of “KJP Morava” residential-commercial building	20.04.2017	03.11.2017	GEFTrustee	SRB MoME	Svilajnac	16656.83		1	109	7	7	109
265	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Main water supply distribution line in Sedlari community (2563m)	1.3.2015	30.3.2016.	JPN			144460.05	1000	3	109	6	10	109
266	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Renovation of water source Perkićevo	1.3.2015	30.3.2016.	JPN			125747.27	15400	3	109	6	10	109
267	Integrated Response VaW			Support to the multisectoral teams to implement Law on Preventing Domestic Violence	08.12.2020	14.03.2021	SIDA					7	110	5	6	110
268	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity developemnt of the police to respond to VaW			SIDA					7	110	5	6	110
269	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity developemnt of the police to respond to VaW			SIDA					7	111	5	6	111
270	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	19.10.2017.	ongoing	GEFTrustee					7	112	7	7	112
271	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	River bank protection in the area of water source Prnjavor (construction of Gabion wall and reconstruction of torrential barrier)	1.3.2015	30.3.2016.	JPN			74846.23	13800	3	112	11	10	112
272	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Construction o 200m3r reservoir 	16.9.2017.	9.11.2017.	USAID			68278.0	1890	3	113	3	10	113
273	Open Communities-Successful Communities	Local Development 	Resilient Development	Extension and furnishing of Kindergarten "Maja"			EU			65519.88	30770	3	113	11	10	113
274	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Preparation of project designs for torrential dam construction and rived bad cleaning/regulation	1.3.2015	30.3.2016.	JPN			18500.0	12450	1	114	11	10	114
275	Integrated Response VaW	Social Inclusion	Social Inclusion	Piloting of the Law on Preventing Domsetic Violence	01.04..2017	01.06.2017	SIDA					9	115	5	6	115
276	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for provision of SOS help-line service	1.5.2017	20.12.2017	SIDA			4921.0	1	7	115	5	6	115
277	Enhancement of Municipal Audit for Accountability and Efficiency in Public Finance Management	Accountable Governance	Public Finance Management	\r\nSupport to LGs for more transparent financing of CSOs projects that address the needs of local communities\r\n	2015-11-01 00:00:00	ongoing	SDC			5000.0		7	115	16	4	115
278	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Construction of bridge over river Ub in Gola Glava community	1.3.2015	30.3.2016.	JPN			95589.03	564	3	116	9	10	116
279	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Reconstruction of Foul water sewerage system in Valjevo	1.3.2015	30.3.2016.	JPN			29415.12	30000	3	116	9	10	116
280	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	To train and employ young Roma women and men in institutions and organizations at the local level	01.02.2018	ongoing	UNHCR			3600.0	1	4	116	10	5	116
281	Enhancement of Municipal Audit for Accountability and Efficiency in Public Finance Management	Accountable Governance	Public Finance Management	\r\nSupport to LGs for more transparent financing of CSOs projects that address the needs of local communities\r\n	2015-11-01 00:00:00	ongoing	SDC			5000.0		7	116	16	4	116
282	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Main water supply distribution line in Varvarin (2150m)	1.3.2015	30.3.2016.	JPN			63751.77	2000	3	117	6	10	117
283	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	19.10.2017.	ongoing	GEFTrustee					7	118	7	7	118
284	EMIS	Energy	Resilient Development	Energy rehabilitation of the “JU CSK Masuka” building	20.04.2017	26.01.2018	GEFTrustee	SRB MoME	Velika Plana	35816.47		3	118	7	7	118
285	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	19.10.2017.	ongoing	GEFTrustee					7	119	7	7	119
286	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	19.10.2017.	ongoing	GEFTrustee					7	120	7	7	120
287	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	To train and employ young Roma women and men in institutions and organizations at the local level	01.02.2018	ongoing	UNHCR			3600.0	1	4	120	10	5	120
288	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	19.10.2017.	ongoing	GEFTrustee					7	121	7	7	121
289	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity development of professionals to implement Law on Preventing Domestic Violence 	1.11.2018	Ongoing	SIDA					9	121	5	6	121
290	Integrated Response VaW	Social Inclusion	Social Inclusion	Support to the multisectoral teams to implement Law on Preventing Domestic Violence	17.10.2018	ongoing	SIDA					9	121	5	6	121
291	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity developemnt of the police to respond to VaW	7.11.2018	ongoing	SIDA					9	121	5	6	121
292	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Garbage truck 16m3	1.4.2018.	1.5.2018.	USAID			93140.0	16500	6	122	11	10	122
293	Reintegration of Roma returnees	Social Inclusion	Social Inclusion	Ensuring access to housing and employment for Roma returnees	01.01.2016	30.06.2018	UNDP			44000.0	80	10	122	1	5	122
294	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for marking 16 days of activism against VaW campaign	1.10.2017	20.12.2017	SIDA			2000.0	1	7	122	5	6	122
295	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for provision of SOS help-line service	1.11.2018	Ongoing	SIDA			5000.0	1	7	122	5	6	122
296	Open Communities-Successful Communities	Local Development 	Resilient Development	Furnishing of Elementary School "Radoje Domanovic"		21.6.2018	EU			24462.37	931	3	122	11	10	122
297	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	To train and employ young Roma women and men in institutions and organizations at the local level	01.02.2018	ongoing	UNHCR			3600.0	1	4	122	10	5	122
298	Enhancement of Municipal Audit for Accountability and Efficiency in Public Finance Management	Accountable Governance	Public Finance Management	Support to LGs for more transparent financing of CSOs projects that address the needs of local communities	2015-11-01 00:00:00	ongoing	SDC			5000.0		7	122	16	4	122
299	EMIS	Energy	Resilient Development	Capacity development of the EMS implementation	19.10.2017.	ongoing	GEFTrustee					7	123	7	7	123
300	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	To train and employ young Roma women and men in institutions and organizations at the local level	01.02.2018	ongoing	UNHCR			3600.0	1	4	124	10	5	124
301	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	River cleaning - 200 m	14.7.2014	31.12.2015.	UNDP			21870.62	30190	3	123	11	10	123
302	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of the Torrential Barrier - 0 m	14.7.2014	31.12.2015.	UNDP			20772.86	30190	3	123	11	10	123
303	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of the Torrential Barrier - 0 m	14.7.2014	31.12.2015.	UNDP			15082.09	30190	3	123	11	10	123
304	EMIS	Energy	Resilient Development	Conceptual design for maintenance of “Heroj Rosa Trifunovic” elementary school building	20.04.2017	12.01.2018	GEFTrustee	SRB MoME	Žabari	30698.53		1	125	7	7	125
305	EMIS	Energy	Resilient Development	Energy recovery of the technical school building and reconstruction of the boiler room	20.04.2017	16.03.2018	GEFTrustee	SRB MoME	Žagubica	50000.0		3	126	7	7	126
306	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	To train and employ young Roma women and men in institutions and organizations at the local level	01.02.2018	ongoing	UNHCR			3600.0	1	4	127	10	5	127
307	Enhancement of Municipal Audit for Accountability and Efficiency in Public Finance Management	Accountable Governance	Public Finance Management	\r\nSupport to LGs for more transparent financing of CSOs projects that address the needs of local communities\r\n	2015-11-01 00:00:00	ongoing	SDC			5000.0		7	127	16	4	127
308	BIOMASS	Energy	Resilient Development	Biomass/biogas combined heat and power (CHP) plant (600 kW installed capacity)	13.11.2015.	01.07.2016.	GEFTrustee			275519.92		3	128	7	7	129
309	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for provision of SOS help-line service	1.11.2018	Ongoing	SIDA			5000.0	1	7	128	5	6	128
310	Enhancement of Municipal Audit for Accountability and Efficiency in Public Finance Management	Accountable Governance	Public Finance Management	\r\nSupport to LGs for more transparent financing of CSOs projects that address the needs of local communities\r\n	2015-11-01 00:00:00	ongoing	SDC			5000.0		7	128	16	4	128
311	CSUD	Climate Change	Resilient Development	Innovation award for innovative idea within Open Data Challenge, Improving management and opening of local climate change related data 	4.6.2018.	Ongoing	GEFTrustee	UNDP	SRB MoE	6000.0		10	130	13	8	130
312	Open Data - Open Opportunities	Innovation, Public Policy and Rule of Law	Accountable Governance 	e-Information Directories piloted, pilot for transport open data release and open data released and updated on the National Open Data Portal	26.7.2017	Ongoing	UNDP	Serbia	DFID			10	67	16	2	67
313	Open Data - Open Opportunities	Innovation, Public Policy and Rule of Law	Accountable Governance	Pilot for transport open data release, open data released and updated on the National Open Data Portal	2.2.2018.	Ongoing	Serbia	DFID				10	96	16	2	96
314	Open Data - Open Opportunities	Innovation, Public Policy and Rule of Law	Accountable Governance	e-Information Directories piloted, data available on e-Information Directories webpage 	26.7.2017.	31.8.2017.	UNDP					10	13	16	2	13
315	Open Data - Open Opportunities	Innovation, Public Policy and Rule of Law	Accountable Governance	e-Information Directories piloted, data available on e-information directories webpage 	26.7.2017.	31.8.2017.	UNDP					10	71	16	2	71
316	Open Data - Open Opportunities	Innovation, Public Policy and Rule of Law	Accountable Governance	e-Information Directories piloted and data available on the e-Information Directories webpage, pilot for transport open data release 	26.7.2017.	2.2.2018.	UNDP	Serbia				10	128	16	2	128
317	Open Data - Open Opportunities	Innovation, Public Policy and Rule of Law	Accountable Governance	e-Information Directories piloted, data available on e-Information Directories webpage 	26.7.2017.	31.8.2017.	UNDP					10	115	16	2	115
318	Open Data - Open Opportunities	Innovation, Public Policy and Rule of Law	Accountable Governance	e-Information Directories piloted, data available on e-Information Directories webpage 	26.7.2017.	31.8.2017.	UNDP					10	57	16	2	57
319	Open Data - Open Opportunities	Innovation, Public Policy and Rule of Law	Accountable Governance	e-Information Directories piloted, pilot for transport open data release and open data released and updated on the National Open Data Portal	2.2.2018.	Ongoing	UNDP	Serbia				10	78	16	2	78
320	Open Data - Open Opportunities	Innovation, Public Policy and Rule of Law	Accountable Governance	e-Information Directories piloted, data available on e-Information Directories webpage 	26.7.2017.	31.8.2017.	UNDP					10	122	16	2	122
321	Open Data - Open Opportunities	Innovation, Public Policy and Rule of Law	Accountable Governance	Pilot for transport open data release, open data released and updated on the National Open Data Portal	2.2.2018.	Ongoing	Serbia					10	116	16	2	116
322	Open Data - Open Opportunities	Innovation, Public Policy and Rule of Law	Accountable Governance	e-Information Directories piloted, pilot for transport open data release and open data released and updated on the National Open Data Portal	26.7.2017.	Ongoing	UNDP	Serbia				10	72	16	2	72
323	Open Data - Open Opportunities	Innovation, Public Policy and Rule of Law	Accountable Governance	Pilot for transport open data release, open data released and updated on the National Open Data Portal	2.2.2018.	Ongoing	Serbia					10	106	16	2	106
324	Open Data - Open Opportunities	Innovation, Public Policy and Rule of Law	Accountable Governance	Open Data released and updated on the National Open Data Portal	17.4.2018.	Ongoing	Serbia	DFID				10	131	16	2	131
325	Open Data - Open Opportunities	Innovation, Public Policy and Rule of Law	Accountable Governance	Pilot for transport open data release, open data released on the National Open Data Portal, membership in the Open Data Working Group	2.2.2018.	Ongoing	Serbia	DFID				10	15	16	2	15
326	Accelerating Accountability Mechanisms in Public Finances	Public Finances	Accountable Governance	Improved management of Serbian Public Finances at multiple levels	15.07.2016.	31.12.2018.	SIDA			2616368.0		6	15	16	4	15
327	Enhancement of Municipal Audit for Accountability and Efficienecny in Public Finance Managment	Public Finances	Accountable Governance	Enhancement of Serbian PFM throught strengthening of Internal and External Audit	01.11.2015.	31.10.2019.	SDC			1666666.0		6	15	16	4	15
328	Serbia at Your Fingertips- Digital Transformation for Development 	Innovation, Public Policy and Rule of Law	Good Governance	IT retrainings program 	10.04.2017.	ongoing	Serbia			1007740.0		4	15	8	2	15
329	Serbia at Your Fingertips- Digital Transformation for Development 	Innovation, Public Policy and Rule of Law	Good Governance 	IT retrainings program 	10.04.2017.	ongoing	Serbia			137040.0		4	72	8	2	72
330	Serbia at Your Fingertips- Digital Transformation for Development 	Innovation, Public Policy and Rule of Law	Good Governance 	IT retrainings program	10.04.2017.	ongoing	Serbia			182012.0		4	67	8	2	67
331	Serbia at Your Fingertips- Digital Transformation for Development 	Innovation, Public Policy and Rule of Law	Good Governance 	IT retrainings program	26.12.2017.	ongoing	Serbia			27810.0		4	128	8	2	128
332	Serbia at Your Fingertips- Digital Transformation for Development 	Innovation, Public Policy and Rule of Law	Good Governance	IT retrainings program	26.12.2017.	ongoing	Serbia			27810.0		4	106	8	2	106
333	Serbia at Your Fingertips- Digital Transformation for Development 	Innovation, Public Policy and Rule of Law	Good Governance	IT retrainings program	26.12.2017.	ongoing	Serbia			29600.0		4	116	8	2	116
334	Serbia at Your Fingertips- Digital Transformation for Development 	Innovation, Public Policy and Rule of Law	Good Governance	IT retrainings program	15.01.2018.	ongoing	Serbia			45436.0		4	24	8	2	24
335	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index			SDC					6	7	16	3	7
336	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Two-way communication with citizens, Local Assembly's Website and Local Assembly Acountability Index			SDC					6	45	16	3	45
337	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	E-parliament (DMS & e-voting) and Local Assembly Acountability Index, ROP amendmends, Public Hearings and Mobile Sessions			SDC					6	57	16	3	57
338	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Citizens Petitions' and Conferences			SDC					6	72	16	3	72
339	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	E-parliament (DMS & e-voting), ROP amendmends, Local Assembly Acountability Index and public hearings			SDC					6	78	16	3	78
340	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index, Assembly Office for Citizens Petitions			SDC					7	110	16	3	110
341	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index and Public Hearings			SDC					6	123	16	3	123
342	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Public Hearings, Public budget portal, Two-way communication with citizens and Local Assembly Acountability Index			SDC					6	128	16	3	128
343	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index			SDC					6	132	16	3	132
344	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index, (E-parliament - DMS & e-voting)			SDC					6	71	16	3	71
345	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Public hearing trainings			SDC					7	6	16	3	6
346	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Two-way communication with citizens and Local Assembly's Website  			SDC					6	13	16	3	13
347	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index			SDC					6	116	16	3	116
348	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index			SDC					6	95	16	3	95
349	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index			SDC					6	131	16	3	131
350	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index			SDC					6	100	16	3	100
351	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index			SDC					6	133	16	3	133
352	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index			SDC					6	134	16	3	134
353	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index			SDC					6	135	16	3	135
354	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index			SDC					6	103	16	3	103
355	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index			SDC					6	66	16	3	66
356	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index and Mobile Committee Sessions			SDC					6	108	16	3	108
357	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index			SDC					6	51	16	3	51
358	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index			SDC					6	84	16	3	84
359	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index			SDC					6	3	16	3	3
360	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index			SDC					6	79	16	3	79
361	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index			SDC					6	77	16	3	77
362	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index			SDC					6	46	16	3	46
363	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	E-parliament (DMS & e-voting) and Conferences			SDC					6	72	16	3	72
364	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	E-parliament (DMS & e-voting)			SDC					6	67	16	3	67
365	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Budget portal			SDC					6	106	16	3	106
366	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Budget portal			SDC					6	83	16	3	83
367	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Budget portal			SDC					6	69	16	3	69
368	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Budget portal			SDC					6	136	16	3	136
369	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Budget portal			SDC					6	137	16	3	137
370	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Budget portal			SDC					6	92	16	3	92
32	Open Communities-Successful Communities	Local Development 	Resilient Development	Renovation and furbishing  of the Social Welfare Centre in Vozdovac 	1.11.2017	15.4.2018	EU			100000.0		3	15	11	10	15
\.


--
-- Data for Name: activities_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.activities_category (id, name) FROM stdin;
1	Technical Documentation
2	Research
3	Infrastructure works
4	Employment
5	Private Sector support
6	Institution Building
7	Capacity development
8	Expert support
9	Normative support
10	Innovative solutions
11	Equipment
\.


--
-- Data for Name: activities_location; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.activities_location (id, name, latitude, longitude) FROM stdin;
1	Aleksinac	43.541666999999997	21.707778000000001
2	Gornje Suhotno	43.475208000000002	21.645489999999999
3	Aleksandrovac	43.458710000000004	21.053160999999999
4	Alibunar	45.079841000000002	20.966332999999999
5	Ilandza	45.168317999999999	20.921313000000001
6	Apatin	45.671760999999996	18.981750000000002
7	Arandjelovac	44.307461000000004	20.557240000000000
8	Bac	45.390920999999999	19.239097999999998
9	Backa Palanka	45.250250000000001	19.396083999999998
10	Bajina Basta	43.971403000000002	19.565950000000001
11	Bajina Basta	43.971403000000002	19.565950000000001
12	Batocina	44.154744000000001	21.079792999999999
13	Becej	45.619222999999998	20.048496000000000
14	Bela Palanka	43.218572999999999	22.314261999999999
15	Belgrade	44.817813000000001	20.456897000000001
16	Savski Venac	44.784689999999998	20.448577000000000
17	Vozdovac	39.783729999999998	-100.445881999999997
18	Beocin	45.209059000000003	19.721112999999999
19	Bojnik	43.014083999999997	21.721133999999999
20	Bor	44.074446999999999	22.099190000000000
21	Bosilegrad	42.499656000000002	22.473268999999998
22	Brus	43.385084999999997	21.032149000000000
23	Bujanovac	42.459167000000001	21.766667000000002
24	Cacak	43.888827999999997	20.344732000000000
25	Crna Trava	42.809939000000000	22.298995999999999
26	Cuprija	43.927500000000002	21.370000000000001
27	Dimitrovgrad	43.014473000000002	22.775710000000000
28	Dimtrovgrad	39.783729999999998	-100.445881999999997
29	Doljevac	43.197038999999997	21.830824000000000
30	Gadzin Han	43.225178999999997	22.032722000000000
31	Gornji Milanovac	44.024161999999997	20.459280000000000
32	Indjija	45.047825000000003	20.080853000000001
33	Ivanjica	43.581668000000001	20.230454999999999
34	Kanjiza	46.064444999999999	20.051648000000000
35	Kikinda	45.825443999999997	20.462738999999999
36	Basaid	45.639156000000000	20.413665000000002
37	Kladovo	44.609397999999999	22.613651999999998
38	Knic	43.925291000000001	20.720229000000000
39	Knjazevac	43.567515999999998	22.255655000000001
40	Koceljeva	44.468204000000000	19.815504000000001
41	Kozarica	44.508938999999998	19.704684000000000
42	Kosjeric	43.998111999999999	19.908021999999999
43	Kostolac	44.714942000000001	21.171091000000001
44	Kragujevac	44.008248000000002	20.914047000000000
45	Kraljevo	43.723579999999998	20.687600000000000
46	Krupanj	44.367500000000000	19.363333000000001
47	Likodra	44.397221999999999	19.431944000000001
48	Krzava	44.353889000000002	19.346111000000001
49	Krusevac	43.582565000000002	21.326599000000002
50	Kula	45.608837999999999	19.532775999999998
51	Kursumlija	43.138413000000000	21.274964000000001
53	Bogovadja	44.316426000000000	20.185794999999999
54	Lapovo	44.185459999999999	21.104921999999998
55	Lazarevac	44.381518000000000	20.261033000000001
57	Leskovac	42.996257000000000	21.948086000000000
58	Ljubovija	44.186788999999997	19.369816000000000
59	Loznica	44.537753000000002	19.225040000000000
61	Stira	44.531055000000002	19.209409999999998
62	Lucani	43.857781000000003	20.137651999999999
64	Mali Zvornik	44.375121000000000	19.105215000000001
65	Medvedja	42.842458999999998	21.584731000000001
67	Nis	43.321503999999997	21.895730000000000
68	Nova Crnja	45.667833999999999	20.607053000000001
70	Novi Becej	45.595931000000000	20.143749000000000
71	Novi Pazar	43.136667000000003	20.512222000000001
73	Obrenovac	44.657437000000002	20.198388000000001
74	Baric	44.653331000000001	20.260636000000002
76	Odzaci	45.508282000000001	19.263672000000000
77	Osecina	44.373103999999998	19.602246000000001
78	Pancevo	44.870232000000001	20.640941000000002
80	Pecinci	44.908921999999997	19.966090000000001
81	Donji Tovarnik	44.813253000000003	19.944884999999999
83	Pirot	43.156458000000001	22.587102000000002
84	Pozega	43.846049000000001	20.045493000000000
85	Presevo	42.309167000000002	21.649166999999998
87	Toplik	43.908264000000003	21.503840000000000
88	Priboj	43.583610999999998	19.525832999999999
90	Prokuplje	43.233452999999997	21.585470000000001
91	Raca	43.012594999999997	21.313858000000000
92	Raska	43.160975999999998	20.533928000000000
94	Razanj	43.674424999999999	21.549205000000001
95	Ruma	45.008290000000002	19.815728000000000
97	Sid	45.128110999999997	19.229700999999999
99	Berkasovo	45.148896000000001	19.259923000000001
100	Senta	45.921632000000002	20.082003000000000
101	Sjenica	43.272835000000001	19.998998000000000
103	Smederevska Palanka	44.366176000000003	20.956700999999999
104	Sombor	45.772655000000000	19.114481000000001
106	Subotica	46.100012999999997	19.664097000000002
107	Palic	46.102285000000002	19.763453999999999
109	Svilajnac	44.233308999999998	21.194727000000000
110	Svrljig	43.414707999999997	22.122160999999998
111	Topola	44.254134999999998	20.678276000000000
113	Tutin	42.990341999999998	20.336704000000001
114	Ub	44.456203000000002	20.073777000000000
116	Valjevo	44.270798999999997	19.886555999999999
117	Varvarin	43.725442000000001	21.368127999999999
119	Veliko Gradiste	44.762810999999999	21.516748000000000
120	Vladicin Han	42.708202000000000	22.066365000000001
122	Vranje	42.553252999999998	21.899338000000000
123	Vrnjacka Banja	43.624153000000000	20.895893000000001
125	Zabari	44.356741000000000	21.214670999999999
126	Zagubica	44.196053999999997	21.786539000000001
127	Zajecar	43.902835000000003	22.278936000000002
129	Botos	45.309561000000002	20.638273999999999
130	Zvezdara	44.801664000000002	20.496109000000001
132	Backi Petrovac	45.360314000000002	19.595217999999999
133	Secanj	45.368487999999999	20.773430999999999
135	Sokobanja	43.644050999999997	21.873072000000001
136	Veliko Gradište	44.762810999999999	21.516748000000000
52	Lajkovac	44.369410999999999	20.165486999999999
56	Lebane	42.922044999999997	21.736951999999999
60	Banja Koviljaca	44.514426999999998	19.158308000000002
63	Majdanpek	44.422311000000001	21.935725999999999
66	Negotin	44.227077999999999	22.530854999999999
69	Nova Varos	43.459705000000000	19.815449000000001
72	Novi Sad	45.255133999999998	19.845175999999999
75	Zabrezje	44.682499999999997	20.202500000000001
79	Paracin	43.860833000000000	21.407778000000000
82	Petrovac na Mlavi	44.378261000000002	21.417075000000001
86	Miratovac	42.256056999999998	21.647008000000000
89	Prijepolje	43.387850999999998	19.647203999999999
93	Supnje	43.274053000000002	20.623166999999999
96	Sabac	44.751862000000003	19.691707000000001
98	Adasevci	45.083168000000001	19.220479000000001
102	Smederevo	44.666215999999999	20.926746999999999
105	Sremska Mitrovica	44.971603999999999	19.616868000000000
108	Surdulica	42.691932999999999	22.170147000000000
112	Trstenik	43.620213999999997	20.998445000000000
115	Uzice	43.856496000000000	19.840273000000000
118	Velika Plana	44.334138000000003	21.076483000000000
121	Vlasotince	42.966656000000000	22.127935999999998
124	Vrnjacka banja	43.624153000000000	20.895893000000001
128	Zrenjanin	45.380268000000001	20.390761000000001
131	Vrbas	45.571328000000001	19.642807999999999
134	Kovin	44.743960000000001	20.976289000000001
137	Blace	43.296373000000003	21.290469000000002
\.


--
-- Data for Name: activities_sdg; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.activities_sdg (id, name) FROM stdin;
1	GOAL 1: No Poverty
2	GOAL 2: Zero Hunger
3	GOAL 3: Good Health and Well-being
4	GOAL 4: Quality Education
5	GOAL 5: Gender Equality
6	GOAL 6: Clean Water and Sanitation
7	GOAL 7: Affordable and Clean Energy
8	GOAL 8: Decent Work and Economic Growth
9	GOAL 9: Industry, Innovation and Infrastructure
10	GOAL 10: Reduced Inequality
11	GOAL 11: Sustainable Cities and Communities
12	GOAL 12: Responsible Consumption and Production
13	GOAL 13: Climate Action
14	GOAL 14: Life Below Water
15	GOAL 15: Life on Land
16	GOAL 16: Peace and Justice Strong Institutions
17	GOAL 17: Partnerships to achieve the Goal
\.


--
-- Data for Name: activities_topic; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.activities_topic (id, name) FROM stdin;
1	Poverty Reduction
2	E-Governance
3	Parliamentary Development
4	Public Finance Management
5	Vulnerable groups
6	Gender Equality
7	Energy Efficiency and Renewable Energy
8	Climate Change
9	Environment
10	Local Municipal Resilience and Disaster Risk Reduction
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can view log entry	1	view_logentry
5	Can add permission	2	add_permission
6	Can change permission	2	change_permission
7	Can delete permission	2	delete_permission
8	Can view permission	2	view_permission
9	Can add group	3	add_group
10	Can change group	3	change_group
11	Can delete group	3	delete_group
12	Can view group	3	view_group
13	Can add user	4	add_user
14	Can change user	4	change_user
15	Can delete user	4	delete_user
16	Can view user	4	view_user
17	Can add content type	5	add_contenttype
18	Can change content type	5	change_contenttype
19	Can delete content type	5	delete_contenttype
20	Can view content type	5	view_contenttype
21	Can add session	6	add_session
22	Can change session	6	change_session
23	Can delete session	6	delete_session
24	Can view session	6	view_session
25	Can add activities	7	add_activities
26	Can change activities	7	change_activities
27	Can delete activities	7	delete_activities
28	Can view activities	7	view_activities
29	Can add category	8	add_category
30	Can change category	8	change_category
31	Can delete category	8	delete_category
32	Can view category	8	view_category
33	Can add location	9	add_location
34	Can change location	9	change_location
35	Can delete location	9	delete_location
36	Can view location	9	view_location
37	Can add sdg	10	add_sdg
38	Can change sdg	10	change_sdg
39	Can delete sdg	10	delete_sdg
40	Can view sdg	10	view_sdg
41	Can add topic	11	add_topic
42	Can change topic	11	change_topic
43	Can delete topic	11	delete_topic
44	Can view topic	11	view_topic
\.


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
1	pbkdf2_sha256$120000$rH4LJ7PkhAp4$dUkR6kma+AZnipnFRFIYfNjMrLc4atQBZH7E7J5mlEg=	\N	t	admin			admin@example.com	t	t	2019-01-22 13:24:03.236918+00
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	permission
3	auth	group
4	auth	user
5	contenttypes	contenttype
6	sessions	session
7	activities	activities
8	activities	category
9	activities	location
10	activities	sdg
11	activities	topic
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	activities	0001_initial	2019-01-22 13:23:56.786734+00
2	activities	0002_auto_20181029_1358	2019-01-22 13:23:56.95248+00
3	activities	0003_auto_20181031_1515	2019-01-22 13:23:57.000155+00
4	activities	0004_auto_20181205_1112	2019-01-22 13:23:57.105943+00
5	activities	0005_auto_20181205_1612	2019-01-22 13:23:57.273269+00
6	activities	0006_auto_20181205_1616	2019-01-22 13:23:57.40172+00
7	contenttypes	0001_initial	2019-01-22 13:23:57.452726+00
8	auth	0001_initial	2019-01-22 13:23:57.802508+00
9	admin	0001_initial	2019-01-22 13:23:57.89656+00
10	admin	0002_logentry_remove_auto_add	2019-01-22 13:23:57.927257+00
11	admin	0003_logentry_add_action_flag_choices	2019-01-22 13:23:57.977207+00
12	contenttypes	0002_remove_content_type_name	2019-01-22 13:23:58.051799+00
13	auth	0002_alter_permission_name_max_length	2019-01-22 13:23:58.091783+00
14	auth	0003_alter_user_email_max_length	2019-01-22 13:23:58.14836+00
15	auth	0004_alter_user_username_opts	2019-01-22 13:23:58.21757+00
16	auth	0005_alter_user_last_login_null	2019-01-22 13:23:58.250886+00
17	auth	0006_require_contenttypes_0002	2019-01-22 13:23:58.259192+00
18	auth	0007_alter_validators_add_error_messages	2019-01-22 13:23:58.306165+00
19	auth	0008_alter_user_username_max_length	2019-01-22 13:23:58.354+00
20	auth	0009_alter_user_last_name_max_length	2019-01-22 13:23:58.422534+00
21	sessions	0001_initial	2019-01-22 13:23:58.540402+00
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.


--
-- Name: activities_activities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.activities_activities_id_seq', 372, true);


--
-- Name: activities_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.activities_category_id_seq', 11, true);


--
-- Name: activities_location_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.activities_location_id_seq', 137, true);


--
-- Name: activities_sdg_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.activities_sdg_id_seq', 17, true);


--
-- Name: activities_topic_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.activities_topic_id_seq', 10, true);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 44, true);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 1, true);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 1, false);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 11, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 21, true);


--
-- Name: activities_activities activities_activities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_activities
    ADD CONSTRAINT activities_activities_pkey PRIMARY KEY (id);


--
-- Name: activities_category activities_category_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_category
    ADD CONSTRAINT activities_category_name_key UNIQUE (name);


--
-- Name: activities_category activities_category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_category
    ADD CONSTRAINT activities_category_pkey PRIMARY KEY (id);


--
-- Name: activities_location activities_location_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_location
    ADD CONSTRAINT activities_location_name_key UNIQUE (name);


--
-- Name: activities_location activities_location_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_location
    ADD CONSTRAINT activities_location_pkey PRIMARY KEY (id);


--
-- Name: activities_sdg activities_sdg_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_sdg
    ADD CONSTRAINT activities_sdg_name_key UNIQUE (name);


--
-- Name: activities_sdg activities_sdg_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_sdg
    ADD CONSTRAINT activities_sdg_pkey PRIMARY KEY (id);


--
-- Name: activities_topic activities_topic_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_topic
    ADD CONSTRAINT activities_topic_name_key UNIQUE (name);


--
-- Name: activities_topic activities_topic_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_topic
    ADD CONSTRAINT activities_topic_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: activities_activities_category_id_5ee61052; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX activities_activities_category_id_5ee61052 ON public.activities_activities USING btree (category_id);


--
-- Name: activities_activities_location_id_e7c311c3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX activities_activities_location_id_e7c311c3 ON public.activities_activities USING btree (location_id);


--
-- Name: activities_activities_sdg_id_7f35a230; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX activities_activities_sdg_id_7f35a230 ON public.activities_activities USING btree (sdg_id);


--
-- Name: activities_activities_sublocation_id_7f8364fd; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX activities_activities_sublocation_id_7f8364fd ON public.activities_activities USING btree (sublocation_id);


--
-- Name: activities_activities_topic_id_c7226839; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX activities_activities_topic_id_c7226839 ON public.activities_activities USING btree (topic_id);


--
-- Name: activities_category_name_67adfab2_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX activities_category_name_67adfab2_like ON public.activities_category USING btree (name varchar_pattern_ops);


--
-- Name: activities_location_name_e05b24f8_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX activities_location_name_e05b24f8_like ON public.activities_location USING btree (name varchar_pattern_ops);


--
-- Name: activities_sdg_name_faa13669_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX activities_sdg_name_faa13669_like ON public.activities_sdg USING btree (name varchar_pattern_ops);


--
-- Name: activities_topic_name_2f162436_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX activities_topic_name_2f162436_like ON public.activities_topic USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_groups_group_id_97559544 ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: activities_activities activities_activitie_category_id_5ee61052_fk_activitie; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_activities
    ADD CONSTRAINT activities_activitie_category_id_5ee61052_fk_activitie FOREIGN KEY (category_id) REFERENCES public.activities_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: activities_activities activities_activitie_location_id_e7c311c3_fk_activitie; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_activities
    ADD CONSTRAINT activities_activitie_location_id_e7c311c3_fk_activitie FOREIGN KEY (location_id) REFERENCES public.activities_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: activities_activities activities_activitie_sublocation_id_7f8364fd_fk_activitie; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_activities
    ADD CONSTRAINT activities_activitie_sublocation_id_7f8364fd_fk_activitie FOREIGN KEY (sublocation_id) REFERENCES public.activities_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: activities_activities activities_activities_sdg_id_7f35a230_fk_activities_sdg_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_activities
    ADD CONSTRAINT activities_activities_sdg_id_7f35a230_fk_activities_sdg_id FOREIGN KEY (sdg_id) REFERENCES public.activities_sdg(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: activities_activities activities_activities_topic_id_c7226839_fk_activities_topic_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_activities
    ADD CONSTRAINT activities_activities_topic_id_c7226839_fk_activities_topic_id FOREIGN KEY (topic_id) REFERENCES public.activities_topic(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

