--
-- PostgreSQL database dump
--

-- Dumped from database version 10.6 (Debian 10.6-1.pgdg90+1)
-- Dumped by pg_dump version 10.6 (Debian 10.6-1.pgdg90+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: activities_activities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.activities_activities (
    id integer NOT NULL,
    project_name character varying(300) NOT NULL,
    portfolio character varying(50) NOT NULL,
    cluster character varying(50) NOT NULL,
    specific_activity character varying(300) NOT NULL,
    start_date character varying(50) NOT NULL,
    end_date character varying(50),
    donor_1 character varying(50),
    donor_2 character varying(50),
    donor_3 character varying(50),
    activity_value character varying(50),
    beneficiaries character varying(50),
    category_id integer NOT NULL,
    location_id integer NOT NULL,
    sdg_id integer NOT NULL,
    topic_id integer NOT NULL,
    sublocation_id integer
);


ALTER TABLE public.activities_activities OWNER TO postgres;

--
-- Name: activities_activities_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.activities_activities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.activities_activities_id_seq OWNER TO postgres;

--
-- Name: activities_activities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.activities_activities_id_seq OWNED BY public.activities_activities.id;


--
-- Name: activities_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.activities_category (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.activities_category OWNER TO postgres;

--
-- Name: activities_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.activities_category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.activities_category_id_seq OWNER TO postgres;

--
-- Name: activities_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.activities_category_id_seq OWNED BY public.activities_category.id;


--
-- Name: activities_location; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.activities_location (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    latitude numeric(30,15) NOT NULL,
    longitude numeric(30,15) NOT NULL
);


ALTER TABLE public.activities_location OWNER TO postgres;

--
-- Name: activities_location_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.activities_location_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.activities_location_id_seq OWNER TO postgres;

--
-- Name: activities_location_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.activities_location_id_seq OWNED BY public.activities_location.id;


--
-- Name: activities_sdg; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.activities_sdg (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.activities_sdg OWNER TO postgres;

--
-- Name: activities_sdg_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.activities_sdg_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.activities_sdg_id_seq OWNER TO postgres;

--
-- Name: activities_sdg_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.activities_sdg_id_seq OWNED BY public.activities_sdg.id;


--
-- Name: activities_topic; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.activities_topic (
    id integer NOT NULL,
    name character varying(100) NOT NULL
);


ALTER TABLE public.activities_topic OWNER TO postgres;

--
-- Name: activities_topic_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.activities_topic_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.activities_topic_id_seq OWNER TO postgres;

--
-- Name: activities_topic_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.activities_topic_id_seq OWNED BY public.activities_topic.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO postgres;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_user_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_user_groups_id_seq OWNED BY public.auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO postgres;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_user_id_seq OWNED BY public.auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_user_user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_user_user_permissions_id_seq OWNED BY public.auth_user_user_permissions.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO postgres;

--
-- Name: activities_activities id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_activities ALTER COLUMN id SET DEFAULT nextval('public.activities_activities_id_seq'::regclass);


--
-- Name: activities_category id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_category ALTER COLUMN id SET DEFAULT nextval('public.activities_category_id_seq'::regclass);


--
-- Name: activities_location id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_location ALTER COLUMN id SET DEFAULT nextval('public.activities_location_id_seq'::regclass);


--
-- Name: activities_sdg id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_sdg ALTER COLUMN id SET DEFAULT nextval('public.activities_sdg_id_seq'::regclass);


--
-- Name: activities_topic id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_topic ALTER COLUMN id SET DEFAULT nextval('public.activities_topic_id_seq'::regclass);


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: auth_user id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user ALTER COLUMN id SET DEFAULT nextval('public.auth_user_id_seq'::regclass);


--
-- Name: auth_user_groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups ALTER COLUMN id SET DEFAULT nextval('public.auth_user_groups_id_seq'::regclass);


--
-- Name: auth_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_user_user_permissions_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Data for Name: activities_activities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.activities_activities (id, project_name, portfolio, cluster, specific_activity, start_date, end_date, donor_1, donor_2, donor_3, activity_value, beneficiaries, category_id, location_id, sdg_id, topic_id, sublocation_id) FROM stdin;
1	BIOMASS	Energy	Resilient Development	Construction of biogas combined heat and power plant	13.11.2015.	02.03.2018.	GEFTrustee			222400.4		3	1	7	7	2
2	Integrated Response VaW	Social Inclusion	Social Inclusion	Training of police officers to respond to domestic violence			SIDA					7	1	5	6	1
3	Enhancement of Municipal Audit for Accountability and Efficiency in Public Finance Management	Accountable Governance 	Public Finance Management 	Improving transparency and increasing public participation in local budget management 	2015-11-01 00:00:00	Ongoing	SDC			6000.0		7	1	16	4	1
4	BIOMASS	Energy	Resilient Development	Construction of biogas combined heat and power plant	13.11.2015.	01.07.2016.	GEFTrustee			275519.92		3	3	7	7	4
5	Integrated Response VaW	Social Inclusion	Social Inclusion	Improving cooperation among police, social workers, prosecutors and others working on domestic violence	24.10.2017	13.02.2018	SIDA					7	5	5	6	5
6	Integrated Response VaW	Social Inclusion	Social Inclusion	Training of police officers to respond to domestic violence			SIDA					7	5	5	6	5
7	Integrated Response VaW	Social Inclusion	Social Inclusion	Training of police officers to respond to domestic violence			SIDA					7	6	5	6	6
8	BIOMASS	Energy	Resilient Development	Construction of biogas combined heat and power plant	13.11.2015.	01.12.2016; 13.12.2017.	GEFTrustee			826559.76		3	7	7	7	7
9	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	Training and employment of young Roma in local institutions	01.02.2018	ongoing	UNHCR			3600.0	1	4	8	10	5	8
11	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of the torrential barrier 	14.7.2014	31.12.2015.	UNDP			66767.56	27904	3	11	11	10	11
12	Integrated Response VaW	Social Inclusion	Social Inclusion	Improving cooperation among police, social workers, prosecutors and others working on domestic violence	14.12.2017	01.02.2017	SIDA					7	12	5	6	12
13	Integrated Response VaW	Social Inclusion	Social Inclusion	Training of police officers to respond to domestic violence			SIDA					7	12	5	6	12
14	MEAs	ENV & NRM		Local Adaptation Activities and Measures	2018-09-01 00:00:00	2018-12-31 00:00:00	GEFTrustee			5000.0		7	13	13	8	13
15	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	Training and employment of young Roma in local institutions	01.02.2018	ongoing	UNHCR			3600.0	1	4	14	10	5	14
16	Open Communities-Successful Communities	Local Development 	Resilient Development	Procurement of waste collection truck for Public Utility Company	4.12.2017	26.7.2018	EU			74626.0	12135	3	14	11	10	14
17	Strengthening local resilience in Serbia: Mitigating the impact of the migration crisis	Local Resilience Development	Resilient Development	Procurement of the septic truck for Public Utility Company	17.3.2016.	17.8.2017.	SIDA			73760.0	1683960	3	15	11	10	15
18	strenghtening local resilience	Local Resilience Development	Resilient Development	Procurement of a vehicle for the Center for Social Work	1.1.2016.	31.12.2016.	UNDP			12300.0	1683960	6	15	11	10	15
19	strenghtening local resilience	Local Resilience Development	Resilient Development	Procurement of pick-up vehicle for the Institute for Biocides and Medical Ecology	1.1.2016	31.12.2016	UNDP			11734.0	980	3	15	11	10	15
20	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for SOS domestic violence help-line 	1.5.2017	20.12.2017	SIDA			2500.0	1	7	15	5	6	15
21	Integrated Response VaW	Social Inclusion	Social Inclusion	Organizing campaign on violence against women 	1.10.2017	20.12.2017	SIDA			2000.0	1	7	15	5	6	15
22	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for SOS domestic violence help-line 	1.11.2018	Ongoing	SIDA			5000.0	1	7	15	5	6	15
23	Integrated Response VaW	Social Inclusion	Social Inclusion	Improving media reporting on violence against women	1.10.2017	Ongoing	SIDA			10000.0	27	7	15	5	6	15
24	Open Communities-Successful Communities	Local Development 	Resilient Development	Techical documentation for reconstruction of the Institute of Emergency Medical Assistance	22.7.2018	22.12.2018	EU			75000.0	1000000	1	15	11	10	15
25	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	Training and employment of young Roma in local institutions	01.02.2018	ongoing	UNHCR			3600.0	1	4	16	10	5	16
26	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	Training and employment of young Roma in local institutions	01.02.2018	ongoing	UNHCR			18000.0	5	4	15	10	5	15
27	Autonomy, Voice and Participation of PWDs in Serbia	Social Inclusion	Social Inclusion	Training of civil society to advocate for human rights & employment of people with disabilitiess  	01.06.2018.	ongoing	UN			2000.0	20	7	15	10	5	15
28	Integrated Response VaW	Social Inclusion	Social Inclusion	Training of officials on how to help vulnerable and marginalized women facing violence	1.11.2018	Ongoing	SIDA					9	17	5	6	17
29	Integrated Response VaW	Social Inclusion	Social Inclusion	Improving cooperation among police, social workers, prosecutors and others working on domestic violence	17.10.2018	ongoing	SIDA					9	17	5	6	17
30	Integrated Response VaW	Social Inclusion	Social Inclusion	Training of police officers to respond to domestic violence	7.11.2018	ongoing	SIDA					9	17	5	6	17
31	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity development of professionals to implement Law on Preventing Domestic Violence 	1.11.2018	Ongoing	SIDA					9	18	5	6	18
32	Integrated Response VaW	Social Inclusion	Social Inclusion	Improving cooperation among police, social workers, prosecutors and others working on domestic violence	17.10.2018	ongoing	SIDA					9	18	5	6	18
33	Integrated Response VaW	Social Inclusion	Social Inclusion	Training of police officers to respond to domestic violence	7.11.2018	ongoing	SIDA					9	18	5	6	18
34	Strengthening local resilience in Serbia: Mitigating the impact of the migration crisis	Local Resilience Development	Resilient Development	Design for the waste water treatement facility 	17.3.2016.	17.8.2017.	JPN			65000.0	2624	1	19	11	10	19
35	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Design for Emergency Room reconstruction 	12.3.2017.	25.4.2017.	USAID			5910.0	2624	1	19	3	10	19
36	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Reconstruction of Emergency Room 	1.6.2017.	20.10.2017.	USAID			109980.0	2624	3	19	3	10	19
37	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Procurement of equipment and furniture for Emergency Room	20.10.2017.	21.11.2017.	USAID			10000.0	2624	11	19	3	10	19
38	Open Communities-Successful Communities	Local Development 	Resilient Development	Procurement of Terrain Vehicle for Emergency Responce Team 	20.11.2017	30.11.2017	EU			15642.78	8129	11	19	11	10	19
39	Open Communities-Successful Communities	Local Development 	Resilient Development	Procurement of waste containers for Public Utility Company		30.11.2017	EU			3888.8	8129	11	19	11	10	19
40	Integrated Response VaW	Social Inclusion	Social Inclusion	Organizing campaign on violence against women 	1.10.2017	20.12.2017	SIDA			1998.0	1	7	20	5	6	20
41	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Design for water well	2017-08-01 00:00:00	1.11.2017.	USAID			25000.0	804	1	21	6	10	21
42	Open Communities-Successful Communities	Local Development 	Resilient Development	Procurement of waste collection truck for the Public Utility Company	4.12.2017	26.7.2018	EU			74626.0	38000	11	21	11	10	21
43	Open Communities-Successful Communities	Local Development 	Resilient Development	Procurement of waste containers for the Public Utility Company		8.10.2018	EU			2376.56	38200	11	21	11	10	21
44	Open Communities-Successful Communities	Local Development 	Resilient Development	Hydrogeologic Research and drilling of the exploratory well	25.10.2017	1.5.2018	EU			24200.0	10000	2	21	11	10	21
45	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	Training and employment of young Roma in local institutions	01.02.2018	ongoing	UNHCR			3600.0	1	4	21	10	5	21
46	Integrated Response VaW	Social Inclusion	Social Inclusion	Piloting of the Law on Preventing Domsetic Violence	01.04.2017	01.06.2017	SIDA					9	22	5	6	22
47	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity development of professionals to implement Law on Preventing Domestic Violence 	1.11.2018	Ongoing	SIDA					9	23	5	6	23
48	Integrated Response VaW	Social Inclusion	Social Inclusion	Improving cooperation among police, social workers, prosecutors and others working on domestic violence	17.10.2018	ongoing	SIDA					9	23	5	6	23
49	Integrated Response VaW	Social Inclusion	Social Inclusion	Training of police officers to respond to domestic violence	7.11.2018	ongoing	SIDA					9	23	5	6	23
50	CSUD	Climate change	Resilient Development	Using open public data for climate change mitigation and adaptation	04.06.2018	Ongoing	GEFTrustee	UNDP	SRB MoE	8000.0		10	24	13	8	24
51	Strengthening local resilience in Serbia: Mitigating the impact of the migration crisis	Local Resilience Development	Resilient Development	Procurement of waste collection truck for the Public Utility Company	17.3.2016.	17.8.2017.	JPN			93140.0	6278	11	25	11	10	25
52	Open Communities-Successful Communities	Local Development 	Resilient Development	Reconstruction of Social Welfare Centre	17.10.2017	31.1.2018	EU			19759.47	1493	3	25	11	10	25
54	Integrated Response VaW	Social Inclusion	Social Inclusion	Improving cooperation among police, social workers, prosecutors and others working on domestic violence	08.12.2018	14.03.2019	SIDA					7	27	5	6	27
55	Integrated Response VaW	Social Inclusion	Social Inclusion	Training of police officers to respond to domestic violence			SIDA					7	27	5	6	27
56	Integrated Response VaW	Social Inclusion	Social Inclusion	Improving cooperation among police, social workers, prosecutors and others working on domestic violence	08.12.2019	14.03.2020	SIDA					7	28	5	6	28
57	Integrated Response VaW	Social Inclusion	Social Inclusion	Training of police officers to respond to domestic violence			SIDA					7	28	5	6	28
58	Strengthening local resilience in Serbia: Mitigating the impact of the migration crisis	Local Resilience Development	Resilient Development	Reconstruction of the Red Cross building	17.3.2016.	17.8.2017.	JPN			69841.0	1930	3	29	11	10	29
59	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Reconstruction of municipal Fairgrounds 	18.10.2016	20.11.2016.	USAID			54536.0	9871	3	29	11	10	29
60	Open Communities-Successful Communities	Local Development 	Resilient Development	Reconstruction of the Fire Brigade Premises	15.8.2018	20.12.2018	EU			95150.0	25000	3	29	11	10	29
61	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Reconstruction of kindergarten 	5.5.2017.	19.7.2017.	USAID			33796.0	110	3	30	4	10	31
62	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Procurement of Furniture for Kindergarden	20.7.2017.	31.7.2017.	USAID			5726.0	110	11	30	4	10	31
63	Integrated Response VaW	Social Inclusion	Social Inclusion	Organizing campaign on violence against women 	1.10.2017	20.12.2017	SIDA			2000.0	1	7	30	5	6	30
64	Open Communities-Successful Communities	Local Development 	Resilient Development	Procurement of Septic Cleaning Truck 	4.12.2017	8.5.2018	EU			70976.0	59453	11	30	11	10	30
65	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Construction of rain water collector in Brza Palanka sewerage	1.3.2015	30.3.2016.	JPN			23231.69	720	3	32	6	10	32
66	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Designs for torrential dam construction and river bed regulation	1.3.2015	30.3.2016.	JPN			8000.0	465	1	32	11	10	32
67	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Preparation of project designs for torrential dam construction and rived bad cleaning/regulation	1.3.2015	30.3.2016.	JPN			11000.0	212	1	32	11	10	32
68	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity development of professionals to implement Law on Preventing Domestic Violence 	1.11.2018	Ongoing	SIDA					9	32	5	6	32
69	Integrated Response VaW	Social Inclusion	Social Inclusion	Improving cooperation among police, social workers, prosecutors and others working on domestic violence	17.10.2018	ongoing	SIDA					9	32	5	6	32
70	Integrated Response VaW	Social Inclusion	Social Inclusion	Training of police officers to respond to domestic violence	7.11.2018	ongoing	SIDA					9	32	5	6	32
71	Integrated Response VaW	Social Inclusion	Social Inclusion	Improving cooperation among police, social workers, prosecutors and others working on domestic violence	14.12.2017	01.02.2017	SIDA					7	33	5	6	33
72	Integrated Response VaW	Social Inclusion	Social Inclusion	Training of police officers to respond to domestic violence			SIDA					7	33	5	6	33
73	EMIS	Energy	Resilient Development	Improvement of energy efficiency of a high school building	20.04.2017	08.12.2017	GEFTrustee	SRB MoME	Knjaževac	48663.0		3	34	7	7	34
74	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Designs for torrential dam construction and river bed regulation	1.3.2015	30.3.2016.	JPN			8000.0	210	1	35	11	10	35
75	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Preparation of project designs for torrential dam construction and rived bad cleaning/regulation	1.3.2015	30.3.2016.	JPN			8000.0	204	1	35	11	10	35
76	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Rehabilitation of landslide, wells in Đukovine 	1.3.2015	30.3.2016.	JPN			15100.0	343	1	35	11	10	35
78	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of the torrential barrier	14.7.2014	31.12.2015.	UNDP			36964.02	12743	3	36	11	10	36
79	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of the torrential barrier	14.7.2014	31.12.2015.	UNDP			56764.79	12743	3	36	11	10	38
80	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	Training and employment of young Roma in local institutions	01.02.2018	ongoing	UNHCR			3600.0	1	4	39	10	5	39
81	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Design for partial regulation of Lepenica river 	1.3.2015	30.3.2016.	JPN			16800.0	92000	1	40	11	10	40
82	Autonomy, Voice and Participation of PWDs in Serbia	Social Inclusion	Social Inclusion	Training of civil society to advocate for human rights & employment of people with disabilitiess  	01.06.2018.	ongoing	UN			2000.0	20	7	40	10	5	40
83	Integrated Response VaW	Social Inclusion	Social Inclusion	Improving cooperation among police, social workers, prosecutors and others working on domestic violence	14.12.2017	01.02.2017	SIDA					7	40	5	6	40
84	Integrated Response VaW	Social Inclusion	Social Inclusion	Work with perpetrators and victims of domestic violence 	1.11.2018	Ongoing	SIDA			10000.0	2	10	40	5	6	40
85	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	Training and employment of young Roma in local institutions	01.02.2018	ongoing	UNHCR			3600.0	1	4	40	10	5	40
86	ReLOaD	Accountable Governance	Public Finance Management	Improving transparency in financing civil society organizations 	1.02.2017	ongoing	EU	UNDP		900000.0	3000	7	40	16	4	40
87	CSUD	Climate Change	Resilient Development	Using open public data for climate change mitigation and adaptation	4.6.2018	Ongoing	GEFTrustee	UNDP	SRB MoE	9000.0		10	40	13	8	40
88	Enhancement of Municipal Audit for Accountability and Efficiency in Public Finance Management	Accountable Governance 	Public Finance Managment	Increasing participation of civil society and media in local budget management 	2015-11-01 00:00:00	Ongoing	SDC			5000.0		7	40	16	4	40
89	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for SOS domestic violence help-line 	1.5.2017	20.12.2017	SIDA			4500.0	1	7	41	5	6	41
90	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for SOS domestic violence help-line 	1.11.2018	Ongoing	SIDA			5000.0	1	7	41	5	6	41
91	CSUD	Climate Change	Resilient Development	Using open public data for climate change mitigation and adaptation	04.06.2018.	Ongoing	GEFTrustee	UNDP	SRB MoE	4000.0		10	41	13	8	41
92	CSUD	Climate Change	Resilient Development	Improving detection of forest fires 	27.4.2018.	Ongoing	GEFTrustee	UNDP	SRB MoE	5000.0		10	41	13	8	41
93	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Construction of a bridge 	1.3.2015	30.3.2016.	JPN			102910.32	3000	3	42	11	10	42
94	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Design for rehabilitation of the tailing 'Stolice' mine landfill	1.3.2015	30.3.2016.	JPN			204300.0	15000	1	42	11	10	43
95	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Rehabilitation of landslide 	1.3.2015	30.3.2016.	JPN			94849.47	842	3	42	11	10	44
96	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of the torrential barrier	14.7.2014	31.12.2015.	UNDP			29486.71	18427	3	42	11	10	45
97	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of the torrential barrier	14.7.2014	31.12.2015.	UNDP			42946.82	18427	3	42	11	10	42
98	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of the torrential barrier	14.7.2014	31.12.2015.	UNDP			28707.45	18427	3	42	11	10	42
99	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of the torrential barrier	14.7.2014	31.12.2015.	UNDP			52791.66	18427	3	42	11	10	42
100	CSUD	Climate Change	Resilient Development	Using open public data for climate change mitigation and adaptation	04.06.2018.	Ongoing	GEFTrustee	UNDP	SRB MoE	7000.0		10	42	13	8	42
101	EMIS	Energy	Resilient Development	Improvement of energy efficiency of  public building 	20.04.2017	Ongoing	GEFTrustee	SRB MoME	Kruševac	16114.52		3	46	7	7	46
102	Integrated Response VaW	Social Inclusion	Social Inclusion	Piloting of the Law on Preventing Domsetic Violence	01.04.2017	01.06.2017	SIDA					9	46	5	6	46
103	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for SOS domestic violence help-line 	1.5.2017	20.12.2017	SIDA			5000.0	1	7	46	5	6	46
104	CSUD	Climate Change	Resilient Development	Using open public data for climate change mitigation and adaptation	04.06.2018	Ongoing	GEFTrustee	UNDP	SRB MoE	10000.0		10	46	13	8	46
105	CSUD	Climate Change	Resilient Development	Introducing new business model for municipal energy management	27.04.2018.	ongoing	GEFTrustee	UNDP	SRB MoE	4000.0		10	46	13	8	46
106	Enhancement of Municipal Audit for Accountability and Efficiency in Public Finance Management	Accountable Governance 	Public Finance Managment	Increasing participation of civil society and media in local budget management 	2015-11-01 00:00:00	ongoing		SDC		5000.0		7	46	16	4	46
107	Integrated Response VaW	Social Inclusion	Social Inclusion	Improving cooperation among police, social workers, prosecutors and others working on domestic violence	24.10.2017	13.02.2018	SIDA					7	48	5	6	48
108	Integrated Response VaW	Social Inclusion	Social Inclusion	Training of police officers to respond to domestic violence			SIDA					7	48	5	6	48
109	ReLOaD	Accountable Governance 	Public Finance Managment	Improving transparency in financing civil society organizations 	1.02.2017	ongoing	EU	UNDP		900000.0	3000	7	49	16	4	49
110	Strengthening local resilience in Serbia: Mitigating the impact of the migration crisis	Local Resilience Development	Resilient Development	Procurement and installation of children playground mobilier 	17.3.2016.	17.8.2017.	JPN			4161.0	423	3	50	3	10	50
111	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Construction of multifunctional sports field	31.7.2017.	1.9.2017.	USAID			49902.0	1140	3	50	3	10	50
112	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	Training and employment of young Roma in local institutions	01.02.2018	ongoing	UNHCR			3600.0	1	4	50	10	5	50
113	EMIS	Energy	Resilient Development	Reconstruction of the heating system and improvement of thermal insulation of the Town Hall building	20.04.2017	23.02.2018	GEFTrustee	SRB MoME	Lapovo	46895.0		3	51	7	7	51
114	Integrated Response VaW	Social Inclusion	Social Inclusion	Training of police officers to respond to domestic violence			SIDA					7	51	5	6	51
115	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Reconstruction of bridge over Lukavica river	1.3.2015	30.3.2016.	JPN			72769.96	2619	3	52	6	10	52
116	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Study on Flood Risk Management in the Kolubara River Basin	1.3.2015	30.3.2016.	JPN			464250.0	1300000	2	52	11	10	52
117	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity development of professionals to implement Law on Preventing Domestic Violence 	1.11.2018	Ongoing	SIDA					9	53	5	6	53
118	Integrated Response VaW	Social Inclusion	Social Inclusion	Improving cooperation among police, social workers, prosecutors and others working on domestic violence	17.10.2018	ongoing	SIDA					9	53	5	6	53
119	Integrated Response VaW	Social Inclusion	Social Inclusion	Training of police officers to respond to domestic violence	7.11.2018	ongoing	SIDA					9	53	5	6	53
120	Integrated Response VaW	Social Inclusion	Social Inclusion	Organizing campaign on violence against women 	1.10.2017	20.12.2017	SIDA			1865.0	1	7	54	5	6	54
121	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity development of professionals to implement Law on Preventing Domestic Violence 	1.11.2018	Ongoing	SIDA					9	54	5	6	54
122	Integrated Response VaW	Social Inclusion	Social Inclusion	Improving cooperation among police, social workers, prosecutors and others working on domestic violence	17.10.2018	ongoing	SIDA					9	54	5	6	54
123	Enhancement of Municipal Audit for Accountability and Efficiency in Public Finance Management	Accountable Governance	Public Finance Management	Increasing participation of civil society and media in local budget management 	2015-11-01 00:00:00	ongoing	SDC			6000.0		7	54	16	4	54
124	Integrated Response VaW	Social Inclusion	Social Inclusion	Training of police officers to respond to domestic violence	7.11.2018	ongoing	SIDA					9	54	5	6	54
125	EMIS	Energy	Resilient Development	Improvement of energy efficiency of the Town Hall	20.04.2017	18.07.2018	GEFTrustee	SRB MoME	Ljubovija	40959.48		3	55	7	7	55
126	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Construction of the torrential dam on Ljuboviđa river	1.3.2015	30.3.2016.	JPN			160179.56	3000	3	55	9	10	55
127	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Rehabilitation of landslide in Brcic	1.3.2015	30.3.2016.	JPN			14600.0	160	1	55	11	10	55
128	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of the torrential barrier	14.7.2014	31.12.2015.	UNDP			37818.08	15285	3	55	11	10	55
129	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Rehabilitation of landslide in Banja Koviljača	1.3.2015	30.3.2016.	JPN			104997.0	680	3	56	11	10	57
130	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of the torrential barrier	14.7.2014	31.12.2015.	UNDP			44831.51	83915	3	56	11	10	58
131	Open Communities-Successful Communities	Local Development 	Resilient Development	Reconstruction of  an elementary school plateau	10.7.2018	3.9.2018	EU			42544.91	478	3	56	11	10	57
132	Enhancement of Municipal Audit for Accountability and Efficiency in Public Finance Management	Accountable Governance	Public Finance Management	Increasing participation of civil society and media in local budget management 	2015-11-01 00:00:00	ongoing	SDC			6000.0		7	56	16	4	56
133	EMIS	Energy	Resilient Development	Design for reconstruction of the municipal administration building	20.04.2017	28.03.2018	GEFTrustee	SRB MoME	Lučani	50000.0		1	59	7	7	59
134	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Rehabilitation of the landslide in Kapetanska street	1.3.2015	30.3.2016.	JPN			17300.0	5500	1	60	11	10	60
135	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity development of professionals to implement Law on Preventing Domestic Violence 	1.11.2018	Ongoing	SIDA					9	60	5	6	60
136	Integrated Response VaW	Social Inclusion	Social Inclusion	Improving cooperation among police, social workers, prosecutors and others working on domestic violence	17.10.2018	ongoing	SIDA					9	60	5	6	60
137	Integrated Response VaW	Social Inclusion	Social Inclusion	Training of police officers to respond to domestic violence	7.11.2018	ongoing	SIDA					9	60	5	6	60
138	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of the torrential barrier	14.7.2014	31.12.2015.	UNDP			83749.8	13261	3	61	11	10	62
140	EMIS	Energy	Resilient Development	Replacement of the heating system of the Town Hall\n	20.04.2017	03.04.2018	GEFTrustee	SRB MoME	Medvedja	28640.94		3	64	7	7	64
141	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity development of professionals to implement Law on Preventing Domestic Violence 	1.11.2018	Ongoing	SIDA					9	64	5	6	64
142	Integrated Response VaW	Social Inclusion	Social Inclusion	Improving cooperation among police, social workers, prosecutors and others working on domestic violence	17.10.2018	ongoing	SIDA					9	64	5	6	64
143	Integrated Response VaW	Social Inclusion	Social Inclusion	Training of police officers to respond to domestic violence	7.11.2018	ongoing	SIDA					9	64	5	6	64
144	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Construction of the torrential dam and cleaning of the village river  	1.3.2015	30.3.2016.	JPN			87507.4	604	3	65	9	10	65
145	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity development of professionals to implement Law on Preventing Domestic Violence 	1.11.2018	Ongoing	SIDA					9	65	5	6	65
146	Integrated Response VaW	Social Inclusion	Social Inclusion	Improving cooperation among police, social workers, prosecutors and others working on domestic violence	17.10.2018	ongoing	SIDA					9	65	5	6	65
147	Integrated Response VaW	Social Inclusion	Social Inclusion	Training of police officers to respond to domestic violence	7.11.2018	ongoing	SIDA					9	65	5	6	65
148	Reintegration of Roma returnees	Social Inclusion	Social Inclusion	Reconstruction of Roma returnees houses and their employment	01.01.2016	30.06.2018	UNDP			64100.0	142	10	66	1	5	66
149	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	Training and employment of young Roma in local institutions	01.02.2018	ongoing	UNHCR			10800.0	3	4	66	10	5	66
150	Integrated Response VaW	Social Inclusion	Social Inclusion	Improving cooperation among police, social workers, prosecutors and others working on domestic violence	08.12.2017	14.03.2018	SIDA					7	66	5	6	66
151	Integrated Response VaW	Social Inclusion	Social Inclusion	Training of police officers to respond to domestic violence			SIDA					7	66	5	6	66
152	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for SOS domestic violence help-line 	1.5.2017	20.12.2017	SIDA			2000.0	1	7	66	5	6	66
153	Integrated Response VaW	Social Inclusion	Social Inclusion	Organizing campaign on violence against women 	1.10.2017	20.12.2017	SIDA			4000.0	2	7	66	5	6	66
154	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for SOS domestic violence help-line 	1.11.2018	Ongoing	SIDA			5000.0	1	7	66	5	6	66
155	Autonomy, Voice and Participation of PWDs in Serbia	Social Inclusion	Social Inclusion	Training of civil society to advocate for human rights & employment of people with disabilitiess  	01.06.2018.	ongoing	UN			2000.0	20	7	66	10	5	66
156	Blockchain Based Remittances in the City of Nis			Testing blockchain technology for transfer of remittances								10	66	12	1	66
157	Enhancement of Municipal Audit for Accountability and Efficiency in Public Finance Management	Accountable Governance	Public Finance Managament	Increasing participation of civil society and media in local budget management 	2015-11-01 00:00:00	ongoing	SDC			6000.0		7	66	16	4	66
158	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	Training and employment of young Roma in local institutions	01.02.2018	ongoing	UNHCR			3600.0	1	4	67	10	5	67
159	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity development of professionals to implement Law on Preventing Domestic Violence 	1.11.2018	Ongoing	SIDA					9	68	5	6	68
160	Integrated Response VaW	Social Inclusion	Social Inclusion	Improving cooperation among police, social workers, prosecutors and others working on domestic violence	17.10.2018	ongoing	SIDA					9	68	5	6	68
161	Integrated Response VaW	Social Inclusion	Social Inclusion	Training of police officers to respond to domestic violence	7.11.2018	ongoing	SIDA					9	68	5	6	68
162	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for SOS domestic violence help-line 	1.5.2017	20.12.2017	SIDA			4500.0	1	7	69	5	6	69
163	Integrated Response VaW	Social Inclusion	Social Inclusion	Organizing campaign on violence against women 	1.10.2017	20.12.2017	SIDA			1000.0	1	7	69	5	6	69
164	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	Training and employment of young Roma in local institutions	01.02.2018	ongoing	UNHCR			3600.0	1	4	70	10	5	70
165	Enhancement of Municipal Audit for Accountability and Efficiency in Public Finance Management	Accountable Governance	Public Finance Management	Increasing participation of civil society and media in local budget management 	2015-11-01 00:00:00	Ongoing				5000.0		7	70	16	4	70
166	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for SOS domestic violence help-line 	1.5.2017	20.12.2017	SIDA			4990.0	1	7	71	5	6	71
167	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for SOS domestic violence help-line 	1.11.2018	Ongoing	SIDA			5000.0	1	7	71	5	6	71
168	Integrated Response VaW	Social Inclusion	Social Inclusion	Work with perpetrators and victims of domestic violence 	1.11.2018	Ongoing	SIDA			10000.0	2	10	71	5	6	71
169	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	Training and employment of young Roma in local institutions	01.02.2018	ongoing	UNHCR			7200.0	2	4	71	10	5	71
170	Autonomy, Voice and Participation of PWDs in Serbia	Social Inclusion	Social Inclusion	Training of civil society to advocate for human rights & employment of people with disabilitiess  	01.06.2018.	ongoing	UN			2000.0	20	7	71	10	5	71
171	Enhancement of Municipal Audit for Accountability and Efficiency in Public Finance Management	Accoutable Governance	Public Finance Management	Increasing participation of civil society and media in local budget management 	2015-11-01 00:00:00	ongoing	SDC			5000.0		7	71	16	4	71
172	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Rehabilitation of landslide and road in Barič 	1.3.2015	30.3.2016.	JPN			16000.0	500	1	72	11	10	73
173	Open Communities-Successful Communities	Local Development 	Resilient Development	Procurement of the water cistern for the Public Utility Company	4.12.2017	16.5.2018	EU			73700.0	71419	11	72	11	10	72
174	Open Communities-Successful Communities	Local Development 	Resilient Development	Modernization of the Water Treatement Plant "Zabrezje"	23.10.2017	28.2.2018	EU			80753.0	71419	3	72	11	10	74
175	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	Training and employment of young Roma in local institutions	01.02.2018	ongoing	UNHCR			3600.0	1	4	75	10	5	75
176	Integrated Response VaW	Social Inclusion	Social Inclusion	Training of police officers to respond to domestic violence			SIDA					7	75	5	6	75
177	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Contruction of the main water supply line in Karadjordjeva street	1.3.2015.	30.3.2016.	JPN			65816.88	1901-11-20 00:00:00	3	76	6	10	76
178	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Contruction of the main water supply line from KIK reservoir to Osečina 	1.3.2015	30.3.2016.	JPN			60529.75	1200	3	76	6	10	76
179	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of the torrential barrier	14.7.2014	31.12.2015.	UNDP			23683.9	12921	3	76	11	10	76
180	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of the torrential barrier	14.7.2014	31.12.2015.	UNDP			9905.74	12921	3	76	11	10	76
181	Integrated Response VaW	Social Inclusion	Social Inclusion	Organizing campaign on violence against women 	1.10.2017	20.12.2017	SIDA			2000.0	1	7	77	5	6	77
182	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	Training and employment of young Roma in local institutions	01.02.2018	ongoing	UNHCR			3600.0	1	4	77	10	5	77
183	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Construction of rain water collector in Zmić sewerage 	1.3.2015	30.3.2016.	JPN			142562.9	10000	3	78	6	10	78
184	ReLOaD	Accountable Governance	Public Finance Management	Improving transparency in financing civil society organizations 	1.02.2017	Ongoing	EU	UNDP		900000.0	3000	7	78	16	4	78
185	EMIS	Energy	Resilient Development	Construction of thermal insulation and an elementary school heating system improvement 	20.04.2017	Ongoing	GEFTrustee	SRB MoME	Pećinci	29570.63		3	79	7	7	79
186	Open Communities-Successful Communities	Local Development 	Resilient Development	Reconstruction of the the elementary school gym	20.11.2017	23.1.2018	EU			51746.57	658	3	80	11	10	80
187	Enhancement of Municipal Audit for Accountability and Efficiency in Public Finance Management	Accountable Governance 	Public Finance Management	\r\nIncreasing participation of civil society and media in local budget management \r\n	2015-11-01 00:00:00	ongoing	SDC			6000.0		7	81	16	4	81
188	Strengthening local resilience in Serbia: Mitigating the impact of the migration crisis	Local Resilience Development	Resilient Development	Regeneration and reconstruction of five wells at Žujince water spring	17.3.2016.	17.8.2017.	JPN			36750.0	7630	3	82	6	10	82
189	Strengthening local resilience in Serbia: Mitigating the impact of the migration crisis	Local Resilience Development	Resilient Development	Improving operations of Public Utility Company	17.3.2016.	17.8.2017.	JPN			28000.0	9780	7	82	9	10	82
190	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Procurement of 1,000 waste bins 	1.12.2016.	19.12.2016.	USAID			16241.0	2320	11	82	11	10	82
191	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Design for construction of a  water reservoir 	1.8.2017.	28.9.2017.	USAID			23900.0	8400	1	82	6	10	82
192	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Construction of a  reservoir and renovation of existing one	9.10.2017.	24.11.2017.	USAID			308864.0	8400	3	82	6	10	82
193	Open Communities-Successful Communities	Local Development 	Resilient Development 	Construction of the new Emergency medical block 	25.4.2018	24.8.2018	EU			211892.36	34000	3	82	11	10	82
194	Open Communities-Successful Communities	Local Development 	Resilient Development 	Hydrogeologic Research of Toplik Watersource 	24.10.2017	26.12.2018	EU			25000.0	34000	2	82	11	10	82
195	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity development of professionals to implement Law on Preventing Domestic Violence 	1.11.2018	Ongoing	SIDA					9	83	5	6	83
196	Integrated Response VaW	Social Inclusion	Social Inclusion	Improving cooperation among police, social workers, prosecutors and others working on domestic violence	17.10.2018	ongoing	SIDA					9	83	5	6	83
197	Integrated Response VaW	Social Inclusion	Social Inclusion	Training of police officers to respond to domestic violence	7.11.2018	ongoing	SIDA					9	83	5	6	83
198	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity development of professionals to implement Law on Preventing Domestic Violence 	1.11.2018	Ongoing	SIDA					9	84	5	6	84
199	Integrated Response VaW	Social Inclusion	Social Inclusion	Improving cooperation among police, social workers, prosecutors and others working on domestic violence	17.10.2018	ongoing	SIDA					9	84	5	6	84
200	Integrated Response VaW	Social Inclusion	Social Inclusion	Training of police officers to respond to domestic violence	7.11.2018	ongoing	SIDA					9	84	5	6	84
201	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	Training and employment of young Roma in local institutions	01.02.2018	ongoing	UNHCR			3600.0	1	4	85	10	5	85
202	Integrated Response VaW	Social Inclusion	Social Inclusion	Training of police officers to respond to domestic violence			SIDA					7	86	5	6	86
203	EMIS	Energy	Resilient Development	Improving energy efficiency of elementary school building	20.04.2017	09.01.2018	GEFTrustee	SRB MoME	Raška	50000.0		3	87	7	7	87
204	Integrated Response VaW	Social Inclusion	Social Inclusion	Training of police officers to respond to domestic violence			SIDA					7	88	5	6	88
205	Enhancement of Municipal Audit for Accountability and Efficiency in Public Finance Management	Accountable Governance 	Public Finance Management	\r\nIncreasing participation of civil society and media in local budget management \r\n	2015-11-01 00:00:00	ongoing	SDC			5000.0		7	89	16	4	89
206	EMIS	Energy	Resilient Development	Improving energy efficiency of elementary school building	20.04.2017	28.06.2018	GEFTrustee	SRB MoME	Šabac	50000.0		3	90	7	7	90
207	Integrated Response VaW	Social Inclusion	Social Inclusion	Organizing campaign on violence against women 	1.10.2017	20.12.2017	SIDA			1850.0	1	7	90	5	6	90
208	ReLOaD	Accountable Governance 	Public Finance Management	Improving transparency in financing civil society organizations 	1.02.2017	ongoing	EU	UNDP		900000.0	3000	7	90	16	4	90
209	CSUD	Climate Change	Resilient Development	Using open public data for climate change mitigation and adaptation	04.06.2018.	Ongoing	GEFTrustee	UNDP	SRB MoE	5000.0		10	90	13	8	90
210	Strengthening local resilience in Serbia: Mitigating the impact of the migration crisis	Local Resilience Development	Resilient Development	Reconstuction of sport fields in the elementary school in Adasevci 	17.3.2016.	17.8.2017.	JPN			49994.0	530	3	91	3	10	91
211	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Procurement of septic truck	15.11.2016.	31.12.2016.	USAID			73760.0	3560	11	91	11	10	91
212	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Procurement of 10  metal containers	1.12.2016.	20.12.2016.	USAID			7142.0	2050	11	91	11	10	91
213	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Reconstruction of sports field and open gym construction 	30.8.2017.	1.10.2017.	USAID			72063.0	10740	3	91	3	10	91
214	Open Communities-Successful Communities	Local Development 	Resilient Development	Reconstruction and furnishing of elementary school 	4.7.208	18.9.2018	EU			77569.38	987	3	91	11	10	91
215	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Regeneration of two wells and increasing yield in the city pipeline	1.3.2015	30.3.2016.	JPN				10000	3	91	11	10	91
216	Open Communities-Successful Communities	Local Development 	Resilient Development	Procurement of the water transportation cistern for the Public Utility Company	4.12.2017	27.4.2018	EU			73700.0	26392	11	92	11	10	92
217	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	Training and employment of young Roma in local institutions	01.02.2018	ongoing	UNHCR			3600.0	1	4	93	10	5	93
218	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Renovation of water source Buline vode	1.3.2015	30.3.2016.	JPN			39398.2	23600	3	94	11	10	94
220	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for SOS domestic violence help-line 	1.5.2017	20.12.2017	SIDA			2000.0	1	7	94	5	6	94
221	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Procurement of five waste containers	15.3.2017.	20.4.2017.	USAID			3590.0	13200	11	96	11	10	96
222	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Reconstruction of Sports Field and open gym construction 	1.8.2017.	1.11.2017.	USAID			58191.0	25600	3	96	3	10	96
223	Integrated Response VaW	Social Inclusion	Social Inclusion	Improving cooperation among police, social workers, prosecutors and others working on domestic violence	24.10.2017	13.02.2018	SIDA					7	96	5	6	96
224	Integrated Response VaW	Social Inclusion	Social Inclusion	Training of police officers to respond to domestic violence			SIDA					7	96	5	6	96
225	Open Communities-Successful Communities	Local Development 	Resilient Development	Construction of children's playground in Sikara's park	4.7.2018	30.10.2018	EU			24371.0	85903	3	96	11	10	96
226	CSUD	Climate Change	Resilient Development	Using open public data for climate change mitigation and adaptation	4.6.2018	Ongoing	GEFTrustee	UNDP	SRB MoE	7000.0		10	97	13	8	97
227	Strengthening local resilience in Serbia: Mitigating the impact of the migration crisis	Local Resilience Development	Resilient Development	Reconstruction of the basketball court and construction of an open gym at Palić 	17.3.2016.	17.8.2017.	JPN			49900.0	7770	3	98	3	10	99
228	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Reconstruction of the Social Welfare Centre 	3.9.2016.	20.12.2016.	USAID			69485.0	32000	3	98	11	10	98
229	Reintegration of Roma returnees	Social Inclusion	Social Inclusion	Personal documentation and school enrollment for Roma retturnees 	01.01.2016	30.06.2018	UNDP			20000.0	105	4	98	1	5	98
230	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	Training and employment of young Roma in local institutions	01.02.2018	ongoing	UNHCR			3600.0	1	4	98	10	5	98
231	EMIS	Energy	Resilient Development	Design for improving energy efficiency of residential-commercial building "Morava"	20.04.2017	03.11.2017	GEFTrustee	SRB MoME	Svilajnac	16656.83		1	100	7	7	100
232	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Construction of main water supply distribution line in 	1.3.2015	30.3.2016.	JPN			144460.05	1000	3	100	6	10	100
233	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Renovation of water source Perkićevo	1.3.2015	30.3.2016.	JPN			125747.27	15400	3	100	6	10	100
234	Integrated Response VaW			Improving cooperation among police, social workers, prosecutors and others working on domestic violence	08.12.2020	14.03.2021	SIDA					7	101	5	6	101
235	Integrated Response VaW	Social Inclusion	Social Inclusion	Training of police officers to respond to domestic violence			SIDA					7	101	5	6	101
236	Integrated Response VaW	Social Inclusion	Social Inclusion	Training of police officers to respond to domestic violence			SIDA					7	102	5	6	102
237	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Construction of Gabion wall and reconstruction of torrential barrier in Prnjavor	1.3.2015	30.3.2016.	JPN			74846.23	13800	3	103	11	10	103
238	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Construction of reservoir in Vele Polje	16.9.2017.	9.11.2017.	USAID			68278.0	1890	3	104	3	10	104
239	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Designs for torrential dam construction and river bed regulation	1.3.2015	30.3.2016.	JPN			18500.0	12450	1	105	11	10	105
240	Integrated Response VaW	Social Inclusion	Social Inclusion	Piloting of the Law on Preventing Domsetic Violence	01.04..2017	01.06.2017	SIDA					9	106	5	6	106
241	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for SOS domestic violence help-line 	1.5.2017	20.12.2017	SIDA			4921.0	1	7	106	5	6	106
242	Enhancement of Municipal Audit for Accountability and Efficiency in Public Finance Management	Accountable Governance	Public Finance Management	\r\nIncreasing participation of civil society and media in local budget management \r\n	2015-11-01 00:00:00	ongoing	SDC			5000.0		7	106	16	4	106
243	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Construction of bridge over river Ub in Gola Glava	1.3.2015	30.3.2016.	JPN			95589.03	564	3	107	9	10	107
244	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Reconstruction of foul water sewerage system 	1.3.2015	30.3.2016.	JPN			29415.12	30000	3	107	9	10	107
245	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	Training and employment of young Roma in local institutions	01.02.2018	ongoing	UNHCR			3600.0	1	4	107	10	5	107
246	Enhancement of Municipal Audit for Accountability and Efficiency in Public Finance Management	Accountable Governance	Public Finance Management	\r\nIncreasing participation of civil society and media in local budget management \r\n	2015-11-01 00:00:00	ongoing	SDC			5000.0		7	107	16	4	107
247	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Construction of main water supply distribution line 	1.3.2015	30.3.2016.	JPN			63751.77	2000	3	108	6	10	108
248	EMIS	Energy	Resilient Development	Improving energy efficiency of the “JMasuka” building	20.04.2017	26.01.2018	GEFTrustee	SRB MoME	Velika Plana	35816.47		3	109	7	7	109
249	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	Training and employment of young Roma in local institutions	01.02.2018	ongoing	UNHCR			3600.0	1	4	110	10	5	110
250	Integrated Response VaW	Social Inclusion	Social Inclusion	Capacity development of professionals to implement Law on Preventing Domestic Violence 	1.11.2018	Ongoing	SIDA					9	111	5	6	111
251	Integrated Response VaW	Social Inclusion	Social Inclusion	Improving cooperation among police, social workers, prosecutors and others working on domestic violence	17.10.2018	ongoing	SIDA					9	111	5	6	111
252	Integrated Response VaW	Social Inclusion	Social Inclusion	Training of police officers to respond to domestic violence	7.11.2018	ongoing	SIDA					9	111	5	6	111
253	Enhancing Local resilience to the Migration Crisis	Local Resilience Development	Resilient Development	Procurement of the waste collection truck 	1.4.2018.	1.5.2018.	USAID			93140.0	16500	11	112	11	10	112
254	Reintegration of Roma returnees	Social Inclusion	Social Inclusion	Reconstruction of Roma returnees houses and their employment	01.01.2016	30.06.2018	UNDP			44000.0	80	10	112	1	5	112
255	Integrated Response VaW	Social Inclusion	Social Inclusion	Organizing campaign on violence against women 	1.10.2017	20.12.2017	SIDA			2000.0	1	7	112	5	6	112
256	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for SOS domestic violence help-line 	1.11.2018	Ongoing	SIDA			5000.0	1	7	112	5	6	112
257	Open Communities-Successful Communities	Local Development 	Resilient Development	Procurement of furniture for elementary school 		21.6.2018	EU			24462.37	931	3	112	11	10	112
258	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	Training and employment of young Roma in local institutions	01.02.2018	ongoing	UNHCR			3600.0	1	4	112	10	5	112
259	Enhancement of Municipal Audit for Accountability and Efficiency in Public Finance Management	Accountable Governance	Public Finance Management	Increasing participation of civil society and media in local budget management 	2015-11-01 00:00:00	ongoing	SDC			5000.0		7	112	16	4	112
260	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	Training and employment of young Roma in local institutions	01.02.2018	ongoing	UNHCR			3600.0	1	4	113	10	5	113
261	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Cleaning of Novoselska river	14.7.2014	31.12.2015.	UNDP			21870.62	30190	3	114	11	10	114
262	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of torrential barrier at Gocka river	14.7.2014	31.12.2015.	UNDP			20772.86	30190	3	114	11	10	114
263	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of the torrential barrier at Celijska river	14.7.2014	31.12.2015.	UNDP			15082.09	30190	3	114	11	10	114
264	EMIS	Energy	Resilient Development	Design for improvement of energy efficiency of an elementary school building in Aleksandrovac	20.04.2017	12.01.2018	GEFTrustee	SRB MoME	Žabari	30698.53		1	115	7	7	115
265	EMIS	Energy	Resilient Development	Improvement of energy efficiency of the Technical school building 	20.04.2017	16.03.2018	GEFTrustee	SRB MoME	Žagubica	50000.0		3	116	7	7	116
266	Local initiatives for improved social inclusion of young Roma	Social Inclusion	Social Inclusion	Training and employment of young Roma in local institutions	01.02.2018	ongoing	UNHCR			3600.0	1	4	117	10	5	117
267	Enhancement of Municipal Audit for Accountability and Efficiency in Public Finance Management	Accountable Governance	Public Finance Management	\r\nIncreasing participation of civil society and media in local budget management \r\n	2015-11-01 00:00:00	ongoing	SDC			5000.0		7	117	16	4	117
268	BIOMASS	Energy	Resilient Development	Construction of biogas combined heat and power plant	13.11.2015.	01.07.2016.	GEFTrustee			275519.92		3	118	7	7	119
269	Integrated Response VaW	Social Inclusion	Social Inclusion	Grant for SOS domestic violence help-line 	1.11.2018	Ongoing	SIDA			5000.0	1	7	118	5	6	118
270	Enhancement of Municipal Audit for Accountability and Efficiency in Public Finance Management	Accountable Governance	Public Finance Management	\r\nIncreasing participation of civil society and media in local budget management \r\n	2015-11-01 00:00:00	ongoing	SDC			5000.0		7	118	16	4	118
271	CSUD	Climate Change	Resilient Development	Using open public data for climate change mitigation and adaptation	4.6.2018.	Ongoing	GEFTrustee	UNDP	SRB MoE	6000.0		10	120	13	8	120
272	Open Data - Open Opportunities	Innovation, Public Policy and Rule of Law	Accountable Governance 	Making local public data available in opet data format	26.7.2017	Ongoing	UNDP	Serbia	DFID			10	66	16	2	66
273	Open Data - Open Opportunities	Innovation, Public Policy and Rule of Law	Accountable Governance	Making local public data available in opet data format	2.2.2018.	Ongoing	Serbia	DFID				10	90	16	2	90
274	Open Data - Open Opportunities	Innovation, Public Policy and Rule of Law	Accountable Governance	Making local public data available in opet data format	26.7.2017.	31.8.2017.	UNDP					10	13	16	2	13
275	Open Data - Open Opportunities	Innovation, Public Policy and Rule of Law	Accountable Governance	Making local public data available in opet data format	26.7.2017.	31.8.2017.	UNDP					10	70	16	2	70
276	Open Data - Open Opportunities	Innovation, Public Policy and Rule of Law	Accountable Governance	Making local public data available in opet data format	26.7.2017.	2.2.2018.	UNDP	Serbia				10	118	16	2	118
277	Open Data - Open Opportunities	Innovation, Public Policy and Rule of Law	Accountable Governance	Making local public data available in opet data format	26.7.2017.	31.8.2017.	UNDP					10	106	16	2	106
278	Open Data - Open Opportunities	Innovation, Public Policy and Rule of Law	Accountable Governance	Making local public data available in opet data format	26.7.2017.	31.8.2017.	UNDP					10	54	16	2	54
279	Open Data - Open Opportunities	Innovation, Public Policy and Rule of Law	Accountable Governance	Making local public data available in opet data format	2.2.2018.	Ongoing	UNDP	Serbia				10	77	16	2	77
280	Open Data - Open Opportunities	Innovation, Public Policy and Rule of Law	Accountable Governance	Making local public data available in opet data format	26.7.2017.	31.8.2017.	UNDP					10	112	16	2	112
281	Open Data - Open Opportunities	Innovation, Public Policy and Rule of Law	Accountable Governance	Making local public data available in opet data format	2.2.2018.	Ongoing	Serbia					10	107	16	2	107
282	Open Data - Open Opportunities	Innovation, Public Policy and Rule of Law	Accountable Governance	Making local public data available in opet data format	26.7.2017.	Ongoing	UNDP	Serbia				10	71	16	2	71
283	Open Data - Open Opportunities	Innovation, Public Policy and Rule of Law	Accountable Governance	Making local public data available in opet data format	2.2.2018.	Ongoing	Serbia					10	98	16	2	98
284	Open Data - Open Opportunities	Innovation, Public Policy and Rule of Law	Accountable Governance	Making local public data available in opet data format	17.4.2018.	Ongoing	Serbia	DFID				10	121	16	2	121
285	Open Data - Open Opportunities	Innovation, Public Policy and Rule of Law	Accountable Governance	Making local public data available in opet data format	2.2.2018.	Ongoing	Serbia	DFID				10	15	16	2	15
286	Accelerating Accountability Mechanisms in Public Finances	Public Finances	Accountable Governance	Support to Ministry of Finance and state institutions for improving Public Finance Management	15.07.2016.	31.12.2018.	SIDA			2616368.0		6	15	16	4	15
287	Enhancement of Municipal Audit for Accountability and Efficienecny in Public Finance Managment	Public Finances	Accountable Governance	Support to Ministry of Finance, state and local institutions for strengthening internal and external audit	01.11.2015.	31.10.2019.	SDC			1666666.0		6	15	16	4	15
288	Serbia at Your Fingertips- Digital Transformation for Development 	Innovation, Public Policy and Rule of Law	Good Governance	IT trainings 	10.04.2017.	ongoing	Serbia			1007740.0		4	15	8	2	15
289	Serbia at Your Fingertips- Digital Transformation for Development 	Innovation, Public Policy and Rule of Law	Good Governance 	IT trainings 	10.04.2017.	ongoing	Serbia			137040.0		4	71	8	2	71
290	Serbia at Your Fingertips- Digital Transformation for Development 	Innovation, Public Policy and Rule of Law	Good Governance 	IT trainings 	10.04.2017.	ongoing	Serbia			182012.0		4	66	8	2	66
291	Serbia at Your Fingertips- Digital Transformation for Development 	Innovation, Public Policy and Rule of Law	Good Governance 	IT trainings 	26.12.2017.	ongoing	Serbia			27810.0		4	118	8	2	118
292	Serbia at Your Fingertips- Digital Transformation for Development 	Innovation, Public Policy and Rule of Law	Good Governance	IT trainings 	26.12.2017.	ongoing	Serbia			27810.0		4	98	8	2	98
293	Serbia at Your Fingertips- Digital Transformation for Development 	Innovation, Public Policy and Rule of Law	Good Governance	IT trainings 	26.12.2017.	ongoing	Serbia			29600.0		4	107	8	2	107
294	Serbia at Your Fingertips- Digital Transformation for Development 	Innovation, Public Policy and Rule of Law	Good Governance	IT trainings 	15.01.2018.	ongoing	Serbia			45436.0		4	22	8	2	22
295	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index developed / primenjen??			SDC					6	6	16	3	6
296	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	More informative and collaborative Local Assembly's website and Local Assembly Acountability Index developed ??			SDC					6	41	16	3	41
297	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	E-parliament (DMS & e-voting) and Local Assembly Acountability Index, ROP amendmends, Public Hearings and Mobile Sessions			SDC					6	54	16	3	54
298	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Citizens Petitions' and Conferences			SDC					6	71	16	3	71
299	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	E-parliament (DMS & e-voting), ROP amendmends, Local Assembly Acountability Index and public hearings			SDC					6	77	16	3	77
300	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index, Assembly Office for Citizens Petitions			SDC					7	101	16	3	101
301	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index and Public Hearings			SDC					6	114	16	3	114
302	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Public Hearings, Public budget portal, Two-way communication with citizens and Local Assembly Acountability Index			SDC					6	118	16	3	118
303	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index			SDC					6	122	16	3	122
304	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index, (E-parliament - DMS & e-voting)			SDC					6	70	16	3	70
305	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Public hearing trainings			SDC					7	5	16	3	5
306	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Two-way communication with citizens and Local Assembly's Website  			SDC					6	13	16	3	13
307	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index			SDC					6	107	16	3	107
308	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index			SDC					6	89	16	3	89
309	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index			SDC					6	121	16	3	121
310	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index			SDC					6	123	16	3	123
311	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index			SDC					6	124	16	3	124
312	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index			SDC					6	125	16	3	125
313	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index			SDC					6	126	16	3	126
314	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index			SDC					6	94	16	3	94
315	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index			SDC					6	65	16	3	65
316	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index and Mobile Committee Sessions			SDC					6	127	16	3	127
317	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index			SDC					6	49	16	3	49
318	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index			SDC					6	81	16	3	81
319	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index			SDC					6	128	16	3	128
320	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index			SDC					6	78	16	3	78
321	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index			SDC					6	76	16	3	76
322	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Local Assembly Acountability Index			SDC					6	42	16	3	42
323	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	E-parliament (DMS & e-voting) and Conferences			SDC					6	71	16	3	71
324	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	E-parliament (DMS & e-voting)			SDC					6	66	16	3	66
325	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Budget portal developed and made available to local MPs			SDC					6	98	16	3	98
326	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Budget portal developed and made available to local MPs			SDC					6	80	16	3	80
327	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Budget portal developed and made available to local MPs			SDC					6	68	16	3	68
328	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Budget portal developed and made available to local MPs			SDC					6	129	16	3	129
329	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Budget portal developed and made available to local MPs			SDC					6	130	16	3	130
330	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Budget portal developed and made available to local MPs			SDC					6	87	16	3	87
331	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Budget portal developed and made available to local MPs			SDC					6	55	16	3	55
332	Strenghtening the Oversight Function and Transparency of the Parliament	Inclusive Political Processes	Good Governance	Budget portal developed and made available to local MPs			SDC					6	14	16	3	14
10	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of the torrential barrier 	14.7.2014	31.12.2015.	UNDP			29112.24	27904	3	9	11	10	9
77	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of the torrential barrier	14.7.2014	31.12.2015.	UNDP			46437.38	12743	3	36	11	10	36
139	Post Floods Early Recovery 	Local Resilience Development	Resilient Development	Construction of the torrential barrier	14.7.2014	31.12.2015.	UNDP			70259.98	13261	3	61	11	10	61
219	Increased Resilience to Respond to Emergency Situations	Local Resilience Development	Resilient Development	Construction of new water well in Buline vode water source	1.3.2015	30.3.2016.	JPN			31847.01	10000	3	94	11	10	94
53	ReLOaD	Accountable Governance 	Public Finance Management 	Improving transparency in financing civil society organizations 	1.02.2017	ongoing	EU	UNDP		900000.0	3000	7	25	16	4	25
\.


--
-- Data for Name: activities_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.activities_category (id, name) FROM stdin;
1	Technical Documentation
2	Research
3	Infrastructure works
4	Employment
5	Private Sector support
6	Institution Building
7	Capacity development
8	Expert support
9	Normative support
10	Innovative solutions
11	Equipment
\.


--
-- Data for Name: activities_location; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.activities_location (id, name, latitude, longitude) FROM stdin;
1	Aleksinac	43.541666999999997	21.707778000000001
2	Gornje Suhotno	43.475208000000002	21.645489999999999
3	Alibunar	45.079841000000002	20.966332999999999
4	Ilandza	45.168317999999999	20.921313000000001
5	Apatin	45.671760999999996	18.981750000000002
6	Arandjelovac	44.307461000000004	20.557240000000000
7	Bac	45.390920999999999	19.239097999999998
8	Backa Palanka	45.250250000000001	19.396083999999998
9	Bajina Bašta	43.971403000000002	19.565950000000001
10	Kolarski potok	39.783729999999998	-100.445881999999997
11	Bajina Basta	43.971403000000002	19.565950000000001
12	Batocina	44.154744000000001	21.079792999999999
13	Becej	45.619222999999998	20.048496000000000
14	Bela Palanka	43.218572999999999	22.314261999999999
15	Belgrade	44.817813000000001	20.456897000000001
16	Beocin	45.209059000000003	19.721112999999999
17	Bojnik	43.014083999999997	21.721133999999999
18	Bor	44.074446999999999	22.099190000000000
19	Bosilegrad	42.499656000000002	22.473268999999998
20	Brus	43.385084999999997	21.032149000000000
21	Bujanovac	42.459167000000001	21.766667000000002
22	Cacak	43.888827999999997	20.344732000000000
23	Crna Trava	42.809939000000000	22.298995999999999
24	Cuprija	43.927500000000002	21.370000000000001
25	Dimitrovgrad	43.014473000000002	22.775710000000000
26	Dimtrovgrad	39.783729999999998	-100.445881999999997
27	Doljevac	43.197038999999997	21.830824000000000
28	Gadzin Han	43.225178999999997	22.032722000000000
29	Kanjiza	46.064444999999999	20.051648000000000
30	Kikinda	45.825443999999997	20.462738999999999
31	Basaid	45.639156000000000	20.413665000000002
32	Kladovo	44.609397999999999	22.613651999999998
33	Knic	43.925291000000001	20.720229000000000
34	Knjazevac	43.567515999999998	22.255655000000001
35	Koceljeva	44.468204000000000	19.815504000000001
36	Kosjeric	43.998111999999999	19.908021999999999
37	Tmusa	39.783729999999998	-100.445881999999997
38	Seca reka	44.011032999999998	19.838039999999999
39	Kostolac	44.714942000000001	21.171091000000001
40	Kragujevac	44.008248000000002	20.914047000000000
41	Kraljevo	43.723579999999998	20.687600000000000
42	Krupanj	44.367500000000000	19.363333000000001
43	Kostajnik	44.432499999999997	19.299444000000001
44	Likodra	44.397221999999999	19.431944000000001
45	Krzava	44.353889000000002	19.346111000000001
46	Krusevac	43.582565000000002	21.326599000000002
47	Krusevca	39.783729999999998	-100.445881999999997
48	Kula	45.608837999999999	19.532775999999998
49	Kursumlija	43.138413000000000	21.274964000000001
50	Lajkovac	44.369410999999999	20.165486999999999
51	Lapovo	44.185459999999999	21.104921999999998
52	Lazarevac	44.381518000000000	20.261033000000001
53	Lebane	42.922044999999997	21.736951999999999
54	Leskovac	42.996257000000000	21.948086000000000
55	Ljubovija	44.186788999999997	19.369816000000000
56	Loznica	44.537753000000002	19.225040000000000
57	Banja Koviljaca	44.514426999999998	19.158308000000002
58	Stira	44.531055000000002	19.209409999999998
59	Lucani	43.857781000000003	20.137651999999999
60	Majdanpek	44.422311000000001	21.935725999999999
61	Mali Zvornik	44.375121000000000	19.105215000000001
62	Velika reka	44.277479000000000	19.242305999999999
63	Boranjska reka	39.783729999999998	-100.445881999999997
64	Medvedja	42.842458999999998	21.584731000000001
65	Negotin	44.227077999999999	22.530854999999999
66	Nis	43.321503999999997	21.895730000000000
67	Nova Crnja	45.667833999999999	20.607053000000001
68	Nova Varos	43.459705000000000	19.815449000000001
69	Novi Becej	45.595931000000000	20.143749000000000
70	Novi Pazar	43.136667000000003	20.512222000000001
72	Obrenovac	44.657437000000002	20.198388000000001
73	Baric	44.653331000000001	20.260636000000002
75	Odzaci	45.508282000000001	19.263672000000000
76	Osecina	44.373103999999998	19.602246000000001
78	Paracin	43.860833000000000	21.407778000000000
79	Pecinci	44.908921999999997	19.966090000000001
80	Pirot	43.156458000000001	22.587102000000002
82	Presevo	42.309167000000002	21.649166999999998
83	Priboj	43.583610999999998	19.525832999999999
85	Prokuplje	43.233452999999997	21.585470000000001
86	Raca	43.012594999999997	21.313858000000000
87	Raska	43.160975999999998	20.533928000000000
89	Ruma	45.008290000000002	19.815728000000000
90	Sabac	44.751862000000003	19.691707000000001
92	Sjenica	43.272835000000001	19.998998000000000
94	Smederevska Palanka	44.366176000000003	20.956700999999999
96	Sombor	45.772655000000000	19.114481000000001
97	Sremska Mitrovica	44.971603999999999	19.616868000000000
98	Subotica	46.100012999999997	19.664097000000002
99	Palic	46.102285000000002	19.763453999999999
101	Svrljig	43.414707999999997	22.122160999999998
102	Topola	44.254134999999998	20.678276000000000
104	Tutin	42.990341999999998	20.336704000000001
105	Ub	44.456203000000002	20.073777000000000
107	Valjevo	44.270798999999997	19.886555999999999
108	Varvarin	43.725442000000001	21.368127999999999
110	Vladicin Han	42.708202000000000	22.066365000000001
111	Vlasotince	42.966656000000000	22.127935999999998
113	Vrnjacka banja	43.624153000000000	20.895893000000001
114	Vrnjacka Banja	43.624153000000000	20.895893000000001
115	Zabari	44.356741000000000	21.214670999999999
117	Zajecar	43.902835000000003	22.278936000000002
118	Zrenjanin	45.380268000000001	20.390761000000001
120	Zvezdara	44.801664000000002	20.496109000000001
121	Vrbas	45.571328000000001	19.642807999999999
123	Senta	45.921632000000002	20.082003000000000
124	Secanj	45.368487999999999	20.773430999999999
125	Kovin	44.743960000000001	20.976289000000001
127	Surdulica	42.691932999999999	22.170147000000000
129	Veliko Gradiste	44.762810999999999	21.516748000000000
130	Blace	43.296373000000003	21.290469000000002
71	Novi Sad	45.255133999999998	19.845175999999999
74	Zabrezje	44.682499999999997	20.202500000000001
77	Pancevo	44.870232000000001	20.640941000000002
81	Pozega	43.846049000000001	20.045493000000000
84	Prijepolje	43.387850999999998	19.647203999999999
88	Razanj	43.674424999999999	21.549205000000001
91	Sid	45.128110999999997	19.229700999999999
93	Smederevo	44.666215999999999	20.926746999999999
95	Smederervska Palanka	39.783729999999998	-100.445881999999997
100	Svilajnac	44.233308999999998	21.194727000000000
103	Trstenik	43.620213999999997	20.998445000000000
106	Uzice	43.856496000000000	19.840273000000000
109	Velika Plana	44.334138000000003	21.076483000000000
112	Vranje	42.553252999999998	21.899338000000000
116	Zagubica	44.196053999999997	21.786539000000001
119	Botos	45.309561000000002	20.638273999999999
122	Backi Petrovac	45.360314000000002	19.595217999999999
126	Sokobanja	43.644050999999997	21.873072000000001
128	Aleksandrovac	43.458710000000004	21.053160999999999
\.


--
-- Data for Name: activities_sdg; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.activities_sdg (id, name) FROM stdin;
1	GOAL 1: No Poverty
2	GOAL 2: Zero Hunger
3	GOAL 3: Good Health and Well-being
4	GOAL 4: Quality Education
5	GOAL 5: Gender Equality
6	GOAL 6: Clean Water and Sanitation
7	GOAL 7: Affordable and Clean Energy
8	GOAL 8: Decent Work and Economic Growth
9	GOAL 9: Industry, Innovation and Infrastructure
10	GOAL 10: Reduced Inequality
11	GOAL 11: Sustainable Cities and Communities
12	GOAL 12: Responsible Consumption and Production
13	GOAL 13: Climate Action
14	GOAL 14: Life Below Water
15	GOAL 15: Life on Land
16	GOAL 16: Peace and Justice Strong Institutions
17	GOAL 17: Partnerships to achieve the Goal
\.


--
-- Data for Name: activities_topic; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.activities_topic (id, name) FROM stdin;
1	Poverty Reduction
2	E-Governance
3	Parliamentary Development
4	Public Finance Management
5	Vulnerable groups
6	Gender Equality
7	Energy Efficiency and Renewable Energy
8	Climate Change
9	Environment
10	Local Municipal Resilience and Disaster Risk Reduction
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can view log entry	1	view_logentry
5	Can add permission	2	add_permission
6	Can change permission	2	change_permission
7	Can delete permission	2	delete_permission
8	Can view permission	2	view_permission
9	Can add group	3	add_group
10	Can change group	3	change_group
11	Can delete group	3	delete_group
12	Can view group	3	view_group
13	Can add user	4	add_user
14	Can change user	4	change_user
15	Can delete user	4	delete_user
16	Can view user	4	view_user
17	Can add content type	5	add_contenttype
18	Can change content type	5	change_contenttype
19	Can delete content type	5	delete_contenttype
20	Can view content type	5	view_contenttype
21	Can add session	6	add_session
22	Can change session	6	change_session
23	Can delete session	6	delete_session
24	Can view session	6	view_session
25	Can add activities	7	add_activities
26	Can change activities	7	change_activities
27	Can delete activities	7	delete_activities
28	Can view activities	7	view_activities
29	Can add category	8	add_category
30	Can change category	8	change_category
31	Can delete category	8	delete_category
32	Can view category	8	view_category
33	Can add location	9	add_location
34	Can change location	9	change_location
35	Can delete location	9	delete_location
36	Can view location	9	view_location
37	Can add sdg	10	add_sdg
38	Can change sdg	10	change_sdg
39	Can delete sdg	10	delete_sdg
40	Can view sdg	10	view_sdg
41	Can add topic	11	add_topic
42	Can change topic	11	change_topic
43	Can delete topic	11	delete_topic
44	Can view topic	11	view_topic
\.


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
1	pbkdf2_sha256$120000$3nzRbx5ZoOYc$MTwpFPt7z1j3pjj+8ypt4FsHb1KzUi7fBpRohRGk6vY=	\N	t	admin			admin@example.com	t	t	2019-01-17 20:54:29.331295+00
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	permission
3	auth	group
4	auth	user
5	contenttypes	contenttype
6	sessions	session
7	activities	activities
8	activities	category
9	activities	location
10	activities	sdg
11	activities	topic
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	activities	0001_initial	2019-01-17 20:54:22.85502+00
2	activities	0002_auto_20181029_1358	2019-01-17 20:54:22.988688+00
3	activities	0003_auto_20181031_1515	2019-01-17 20:54:23.02392+00
4	activities	0004_auto_20181205_1112	2019-01-17 20:54:23.097129+00
5	activities	0005_auto_20181205_1612	2019-01-17 20:54:23.246502+00
6	activities	0006_auto_20181205_1616	2019-01-17 20:54:23.406515+00
7	contenttypes	0001_initial	2019-01-17 20:54:23.482595+00
8	auth	0001_initial	2019-01-17 20:54:23.865543+00
9	admin	0001_initial	2019-01-17 20:54:23.970303+00
10	admin	0002_logentry_remove_auto_add	2019-01-17 20:54:24.002498+00
11	admin	0003_logentry_add_action_flag_choices	2019-01-17 20:54:24.034721+00
12	contenttypes	0002_remove_content_type_name	2019-01-17 20:54:24.103077+00
13	auth	0002_alter_permission_name_max_length	2019-01-17 20:54:24.128273+00
14	auth	0003_alter_user_email_max_length	2019-01-17 20:54:24.161102+00
15	auth	0004_alter_user_username_opts	2019-01-17 20:54:24.190327+00
16	auth	0005_alter_user_last_login_null	2019-01-17 20:54:24.227649+00
17	auth	0006_require_contenttypes_0002	2019-01-17 20:54:24.250929+00
18	auth	0007_alter_validators_add_error_messages	2019-01-17 20:54:24.279419+00
19	auth	0008_alter_user_username_max_length	2019-01-17 20:54:24.356305+00
20	auth	0009_alter_user_last_name_max_length	2019-01-17 20:54:24.395135+00
21	sessions	0001_initial	2019-01-17 20:54:24.486546+00
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.


--
-- Name: activities_activities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.activities_activities_id_seq', 332, true);


--
-- Name: activities_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.activities_category_id_seq', 11, true);


--
-- Name: activities_location_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.activities_location_id_seq', 130, true);


--
-- Name: activities_sdg_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.activities_sdg_id_seq', 17, true);


--
-- Name: activities_topic_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.activities_topic_id_seq', 10, true);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 44, true);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 1, true);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 1, false);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 11, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 21, true);


--
-- Name: activities_activities activities_activities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_activities
    ADD CONSTRAINT activities_activities_pkey PRIMARY KEY (id);


--
-- Name: activities_category activities_category_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_category
    ADD CONSTRAINT activities_category_name_key UNIQUE (name);


--
-- Name: activities_category activities_category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_category
    ADD CONSTRAINT activities_category_pkey PRIMARY KEY (id);


--
-- Name: activities_location activities_location_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_location
    ADD CONSTRAINT activities_location_name_key UNIQUE (name);


--
-- Name: activities_location activities_location_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_location
    ADD CONSTRAINT activities_location_pkey PRIMARY KEY (id);


--
-- Name: activities_sdg activities_sdg_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_sdg
    ADD CONSTRAINT activities_sdg_name_key UNIQUE (name);


--
-- Name: activities_sdg activities_sdg_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_sdg
    ADD CONSTRAINT activities_sdg_pkey PRIMARY KEY (id);


--
-- Name: activities_topic activities_topic_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_topic
    ADD CONSTRAINT activities_topic_name_key UNIQUE (name);


--
-- Name: activities_topic activities_topic_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_topic
    ADD CONSTRAINT activities_topic_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: activities_activities_category_id_5ee61052; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX activities_activities_category_id_5ee61052 ON public.activities_activities USING btree (category_id);


--
-- Name: activities_activities_location_id_e7c311c3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX activities_activities_location_id_e7c311c3 ON public.activities_activities USING btree (location_id);


--
-- Name: activities_activities_sdg_id_7f35a230; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX activities_activities_sdg_id_7f35a230 ON public.activities_activities USING btree (sdg_id);


--
-- Name: activities_activities_sublocation_id_7f8364fd; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX activities_activities_sublocation_id_7f8364fd ON public.activities_activities USING btree (sublocation_id);


--
-- Name: activities_activities_topic_id_c7226839; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX activities_activities_topic_id_c7226839 ON public.activities_activities USING btree (topic_id);


--
-- Name: activities_category_name_67adfab2_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX activities_category_name_67adfab2_like ON public.activities_category USING btree (name varchar_pattern_ops);


--
-- Name: activities_location_name_e05b24f8_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX activities_location_name_e05b24f8_like ON public.activities_location USING btree (name varchar_pattern_ops);


--
-- Name: activities_sdg_name_faa13669_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX activities_sdg_name_faa13669_like ON public.activities_sdg USING btree (name varchar_pattern_ops);


--
-- Name: activities_topic_name_2f162436_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX activities_topic_name_2f162436_like ON public.activities_topic USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_groups_group_id_97559544 ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: activities_activities activities_activitie_category_id_5ee61052_fk_activitie; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_activities
    ADD CONSTRAINT activities_activitie_category_id_5ee61052_fk_activitie FOREIGN KEY (category_id) REFERENCES public.activities_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: activities_activities activities_activitie_location_id_e7c311c3_fk_activitie; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_activities
    ADD CONSTRAINT activities_activitie_location_id_e7c311c3_fk_activitie FOREIGN KEY (location_id) REFERENCES public.activities_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: activities_activities activities_activitie_sublocation_id_7f8364fd_fk_activitie; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_activities
    ADD CONSTRAINT activities_activitie_sublocation_id_7f8364fd_fk_activitie FOREIGN KEY (sublocation_id) REFERENCES public.activities_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: activities_activities activities_activities_sdg_id_7f35a230_fk_activities_sdg_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_activities
    ADD CONSTRAINT activities_activities_sdg_id_7f35a230_fk_activities_sdg_id FOREIGN KEY (sdg_id) REFERENCES public.activities_sdg(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: activities_activities activities_activities_topic_id_c7226839_fk_activities_topic_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities_activities
    ADD CONSTRAINT activities_activities_topic_id_c7226839_fk_activities_topic_id FOREIGN KEY (topic_id) REFERENCES public.activities_topic(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

